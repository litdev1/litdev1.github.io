Due to my coding limitations, OculusSB will not work unless the Smallbasic directory is:
C:\Program Files (x86)\Microsoft\Small Basic 

It is the default directory of smallbasic.

Place both Dlls and the XML file in Smallbasic\Lib