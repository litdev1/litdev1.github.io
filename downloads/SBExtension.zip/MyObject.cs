﻿using Microsoft.SmallBasic.Library;
using Microsoft.SmallBasic.Library.Internal;
using System;
using System.Reflection;
using System.Windows;

namespace $safeprojectname$
{
    /// <summary>
    /// This is a Small Basic Extension example, showing how to use Propery, Method and Event.
    /// It also shows how to interact with SmallBasicLibrary.
    /// </summary>
    /// <example>
    /// TextWindow.WriteLine(MyObject.MyProperty)
    /// GraphicsWindow.Show()
    /// result = MyObject.MyMethod(0)
    /// TextWindow.WriteLine(result)
    /// MyObject.MyEvent = OnMyEvent
    /// Sub OnMyEvent
    ///   TextWindow.WriteLine("GraphicsWindow Resized")
    /// EndSub
    /// </example>
    [SmallBasicType]
    public class MyObject
    {
        private static string myProperty = "A test Property";
        private static SmallBasicCallback myEventDelegate = null;
        private static void MyEventHandler(object sender, SizeChangedEventArgs e)
        {
            if (null != myEventDelegate) myEventDelegate();
        }

        /// <summary>
        /// This is a test Property.
        /// </summary>
        public static Primitive MyProperty
        {
            get { return myProperty; }
            set { myProperty = value; }
        }

        /// <summary>
        /// This is a test Method.
        /// It shows how to interact with SmallBasicLibrary and add an event handler.
        /// </summary>
        /// <param name="value1">An input value.</param>
        /// <returns>"SUCCEEDED" or "FAILED".</returns>
        public static Primitive MyMethod(Primitive value1)
        {
            Type GraphicsWindowType = typeof(GraphicsWindow);

            Window _window = (Window)GraphicsWindowType.GetField("_window", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase).GetValue(null);
            InvokeHelperWithReturn ret = new InvokeHelperWithReturn(delegate
            {
                try
                {
                    _window.SizeChanged += new SizeChangedEventHandler(MyEventHandler);
                    return "SUCCEEDED";
                }
                catch (Exception ex)
                {
                    TextWindow.WriteLine(ex.Message);
                }
                return "FAILED";
            });
            MethodInfo method = GraphicsWindowType.GetMethod("InvokeWithReturn", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase);
            return method.Invoke(null, new object[] { ret }).ToString();
        }

        /// <summary>
        /// This is a test Event.
        /// It fires when the GraphicsWindow is resized.
        /// </summary>
        public static event SmallBasicCallback MyEvent
        {
            add
            {
                myEventDelegate = value;
            }
            remove
            {
                myEventDelegate = null;
            }
        }
    }
}
