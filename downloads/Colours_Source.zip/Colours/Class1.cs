﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SmallBasic.Library;

namespace Colours
{
    /// <summary>
    /// Gets the Standard SmallBasic Colours.
    /// </summary>
    [SmallBasicType]
    public static class Colour
    {
		// Red Colors
		public static Primitive IndianRed {get{return "#CD5C5C";}}
		public static Primitive LightCoral {get{return "#F08080";}}
		public static Primitive Salmon {get{return "#FA8072";}}
		public static Primitive DarkSalmon {get{return "#E9967A";}}
		public static Primitive LightSalmon {get{return "#FFA07A";}}
		public static Primitive Crimson {get{return "#DC143C";}}
		public static Primitive Red {get{return "#FF0000";}}
		public static Primitive FireBrick {get{return "#B22222";}}
		public static Primitive DarkRed {get{return "#8B0000";}}
		// Pink Colors
		public static Primitive Pink {get{return "#FFC0CB";}}
		public static Primitive LightPink {get{return "#FFB6C1";}}
		public static Primitive HotPink {get{return "#FF69B4";}}
		public static Primitive DeepPink {get{return "#FF1493";}}
		public static Primitive MediumVioletRed {get{return "#C71585";}}
		public static Primitive PaleVioletRed {get{return "#DB7093";}}
		// Orange Colors
		// LightSalmon {get{return "#FFA07A";}}
		public static Primitive Coral {get{return "#FF7F50";}}
		public static Primitive Tomato {get{return "#FF6347";}}
		public static Primitive OrangeRed {get{return "#FF4500";}}
		public static Primitive DarkOrange {get{return "#FF8C00";}}
		public static Primitive Orange {get{return "#FFA500";}}
		// Yellow Colors
		public static Primitive Gold {get{return "#FFD700";}}
		public static Primitive Yellow {get{return "#FFFF00";}}
		public static Primitive LightYellow {get{return "#FFFFE0";}}
		public static Primitive LemonChiffon {get{return "#FFFACD";}}
		public static Primitive LightGoldenrodYellow {get{return "#FAFAD2";}}
		public static Primitive PapayaWhip {get{return "#FFEFD5";}}
		public static Primitive Moccasin {get{return "#FFE4B5";}}
		public static Primitive PeachPuff {get{return "#FFDAB9";}}
		public static Primitive PaleGoldenrod {get{return "#EEE8AA";}}
		public static Primitive Khaki {get{return "#F0E68C";}}
		public static Primitive DarkKhaki {get{return "#BDB76B";}}
		// Purple Colors
		public static Primitive Lavender {get{return "#E6E6FA";}}
		public static Primitive Thistle {get{return "#D8BFD8";}}
		public static Primitive Plum {get{return "#DDA0DD";}}
		public static Primitive Violet {get{return "#EE82EE";}}
		public static Primitive Orchid {get{return "#DA70D6";}}
		public static Primitive Fuchsia {get{return "#FF00FF";}}
		public static Primitive Magenta {get{return "#FF00FF";}}
		public static Primitive MediumOrchid {get{return "#BA55D3";}}
		public static Primitive MediumPurple {get{return "#9370DB";}}
		public static Primitive BlueViolet {get{return "#8A2BE2";}}
		public static Primitive DarkViolet {get{return "#9400D3";}}
		public static Primitive DarkOrchid {get{return "#9932CC";}}
		public static Primitive DarkMagenta {get{return "#8B008B";}}
		public static Primitive Purple {get{return "#800080";}}
		public static Primitive Indigo {get{return "#4B0082";}}
		public static Primitive SlateBlue {get{return "#6A5ACD";}}
		public static Primitive DarkSlateBlue {get{return "#483D8B";}}
		// MediumSlateBlue {get{return "#7B68EE";}}
		// Green Colors
		public static Primitive GreenYellow {get{return "#ADFF2F";}}
		public static Primitive Chartreuse {get{return "#7FFF00";}}
		public static Primitive LawnGreen {get{return "#7CFC00";}}
		public static Primitive Lime {get{return "#00FF00";}}
		public static Primitive LimeGreen {get{return "#32CD32";}}
		public static Primitive PaleGreen {get{return "#98FB98";}}
		public static Primitive LightGreen {get{return "#90EE90";}}
		public static Primitive MediumSpringGreen {get{return "#00FA9A";}}
		public static Primitive SpringGreen {get{return "#00FF7F";}}
		public static Primitive MediumSeaGreen {get{return "#3CB371";}}
		public static Primitive SeaGreen {get{return "#2E8B57";}}
		public static Primitive ForestGreen {get{return "#228B22";}}
		public static Primitive Green {get{return "#008000";}}
		public static Primitive DarkGreen {get{return "#006400";}}
		public static Primitive YellowGreen {get{return "#9ACD32";}}
		public static Primitive OliveDrab {get{return "#6B8E23";}}
		public static Primitive Olive {get{return "#808000";}}
		public static Primitive DarkOliveGreen {get{return "#556B2F";}}
		public static Primitive MediumAquamarine {get{return "#66CDAA";}}
		public static Primitive DarkSeaGreen {get{return "#8FBC8F";}}
		public static Primitive LightSeaGreen {get{return "#20B2AA";}}
		public static Primitive DarkCyan {get{return "#008B8B";}}
		public static Primitive Teal {get{return "#008080";}}
		// Blue Colors
		public static Primitive Aqua {get{return "#00FFFF";}}
		public static Primitive Cyan {get{return "#00FFFF";}}
		public static Primitive LightCyan {get{return "#E0FFFF";}}
		public static Primitive PaleTurquoise {get{return "#AFEEEE";}}
		public static Primitive Aquamarine {get{return "#7FFFD4";}}
		public static Primitive Turquoise {get{return "#40E0D0";}}
		public static Primitive MediumTurquoise {get{return "#48D1CC";}}
		public static Primitive DarkTurquoise {get{return "#00CED1";}}
		public static Primitive CadetBlue {get{return "#5F9EA0";}}
		public static Primitive SteelBlue {get{return "#4682B4";}}
		public static Primitive LightSteelBlue {get{return "#B0C4DE";}}
		public static Primitive PowderBlue {get{return "#B0E0E6";}}
		public static Primitive LightBlue {get{return "#ADD8E6";}}
		public static Primitive SkyBlue {get{return "#87CEEB";}}
		public static Primitive LightSkyBlue {get{return "#87CEFA";}}
		public static Primitive DeepSkyBlue {get{return "#00BFFF";}}
		public static Primitive DodgerBlue {get{return "#1E90FF";}}
		public static Primitive CornflowerBlue {get{return "#6495ED";}}
		public static Primitive MediumSlateBlue {get{return "#7B68EE";}}
		public static Primitive RoyalBlue {get{return "#4169E1";}}
		public static Primitive Blue {get{return "#0000FF";}}
		public static Primitive MediumBlue {get{return "#0000CD";}}
		public static Primitive DarkBlue {get{return "#00008B";}}
		public static Primitive Navy {get{return "#000080";}}
		public static Primitive MidnightBlue {get{return "#191970";}}
		// Brown Colors
		public static Primitive Cornsilk {get{return "#FFF8DC";}}
		public static Primitive BlanchedAlmond {get{return "#FFEBCD";}}
		public static Primitive Bisque {get{return "#FFE4C4";}}
		public static Primitive NavajoWhite {get{return "#FFDEAD";}}
		public static Primitive Wheat {get{return "#F5DEB3";}}
		public static Primitive BurlyWood {get{return "#DEB887";}}
		public static Primitive Tan {get{return "#D2B48C";}}
		public static Primitive RosyBrown {get{return "#BC8F8F";}}
		public static Primitive SandyBrown {get{return "#F4A460";}}
		public static Primitive Goldenrod {get{return "#DAA520";}}
		public static Primitive DarkGoldenrod {get{return "#B8860B";}}
		public static Primitive Peru {get{return "#CD853F";}}
		public static Primitive Chocolate {get{return "#D2691E";}}
		public static Primitive SaddleBrown {get{return "#8B4513";}}
		public static Primitive Sienna {get{return "#A0522D";}}
		public static Primitive Brown {get{return "#A52A2A";}}
		public static Primitive Maroon {get{return "#800000";}}
		// White Colors
		public static Primitive White {get{return "#FFFFFF";}}
		public static Primitive Snow {get{return "#FFFAFA";}}
		public static Primitive Honeydew {get{return "#F0FFF0";}}
		public static Primitive MintCream {get{return "#F5FFFA";}}
		public static Primitive Azure {get{return "#F0FFFF";}}
		public static Primitive AliceBlue {get{return "#F0F8FF";}}
		public static Primitive GhostWhite {get{return "#F8F8FF";}}
		public static Primitive WhiteSmoke {get{return "#F5F5F5";}}
		public static Primitive Seashell {get{return "#FFF5EE";}}
		public static Primitive Beige {get{return "#F5F5DC";}}
		public static Primitive OldLace {get{return "#FDF5E6";}}
		public static Primitive FloralWhite {get{return "#FFFAF0";}}
		public static Primitive Ivory {get{return "#FFFFF0";}}
		public static Primitive AntiqueWhite {get{return "#FAEBD7";}}
		public static Primitive Linen {get{return "#FAF0E6";}}
		public static Primitive LavenderBlush {get{return "#FFF0F5";}}
		public static Primitive MistyRose {get{return "#FFE4E1";}}
		// Gray Colors
		public static Primitive Gainsboro {get{return "#DCDCDC";}}
		public static Primitive LightGray {get{return "#D3D3D3";}}
		public static Primitive Silver {get{return "#C0C0C0";}}
		public static Primitive DarkGray {get{return "#A9A9A9";}}
		public static Primitive Gray {get{return "#808080";}}
		public static Primitive DimGray {get{return "#696969";}}
		public static Primitive LightSlateGray {get{return "#778899";}}
		public static Primitive SlateGray {get{return "#708090";}}
		public static Primitive DarkSlateGray {get{return "#2F4F4F";}}
		public static Primitive Black {get{return "#000000";}}
    }
}
