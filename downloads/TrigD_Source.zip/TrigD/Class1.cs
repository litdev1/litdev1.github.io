﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SmallBasic.Library;

namespace TrigD
{
    /// <summary>
    /// Trig functions with degrees.
    /// </summary>
    [SmallBasicType]
    public static class TrigD
    {
        static double deg2rad = System.Math.PI / 180.0;

        /// <summary>
        /// Sin of an angle in degrees.
        /// </summary>
        /// <param name="angle">
        /// The angle in degrees.
        /// </param>
        /// <returns>
        /// The Sin of the angle.
        /// </returns>
        public static Primitive Sin(Primitive angle)
        {
            return System.Math.Sin(angle * deg2rad);
        }

        /// <summary>
        /// Cos of an angle in degrees.
        /// </summary>
        /// <param name="angle">
        /// The angle in degrees.
        /// </param>
        /// <returns>
        /// The Cos of the angle.
        /// </returns>
        public static Primitive Cos(Primitive angle)
        {
            return System.Math.Cos(angle * deg2rad);
        }

        /// <summary>
        /// Tan of an angle in degrees.
        /// </summary>
        /// <param name="angle">
        /// The angle in degrees.
        /// </param>
        /// <returns>
        /// The Tan of the angle.
        /// </returns>
        public static Primitive Tan(Primitive angle)
        {
            return System.Math.Tan(angle * deg2rad);
        }

        /// <summary>
        /// ArcSin in degrees.
        /// </summary>
        /// <param name="sin">
        /// The Sin of the angle.
        /// </param>
        /// <returns>
        /// The angle in degrees.
        /// </returns>
        public static Primitive ArcSin(Primitive sin)
        {
            return System.Math.Asin(System.Math.Min(1.0, System.Math.Max(-1.0, sin))) / deg2rad;
        }

        /// <summary>
        /// ArcCos in degrees.
        /// </summary>
        /// <param name="cos">
        /// The Cos of the angle.
        /// </param>
        /// <returns>
        /// The angle in degrees.
        /// </returns>
        public static Primitive ArcCos(Primitive cos)
        {
            return System.Math.Acos(System.Math.Min(1.0, System.Math.Max(-1.0, cos))) / deg2rad;
        }

        /// <summary>
        /// ArcTan in degrees.
        /// </summary>
        /// <param name="tan">
        /// The Tan of the angle.
        /// </param>
        /// <returns>
        /// The angle in degrees.
        /// </returns>
        public static Primitive ArcTan(Primitive tan)
        {
            return System.Math.Atan(tan) / deg2rad;
        }
    }
}
