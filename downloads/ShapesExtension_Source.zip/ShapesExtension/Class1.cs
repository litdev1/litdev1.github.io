﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SmallBasic.Library;
using Microsoft.SmallBasic.Library.Internal;
using System.Windows;
using System.Windows.Shapes;
using System.Windows.Controls;
using System.Windows.Media;
using System.Reflection;
using System.Runtime.InteropServices;

namespace ShapesExtension
{
    /// <summary>
    /// Shapes extension utilities.
    /// </summary>
    [SmallBasicType]
    public static class ShapesExtension
    {
        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
        [DllImport("user32.dll", SetLastError = true)]
        private static extern int SendMessage(IntPtr hWnd, Int32 wMsg, bool wParam, Int32 lParam);
        private const int WM_SETREDRAW = 11;

        /// <summary>
        /// Reset the Turtle after a GraphicsWindow.Clear().
        /// </summary>
        /// <returns>
        /// None.
        /// </returns>
        public static void ResetTurtle()
        {
            Type GraphicsWindowType = typeof(GraphicsWindow);
            Type TurtleType = typeof(Turtle);
            Dictionary<string, UIElement> _objectsMap;
            UIElement obj;
            bool _initialized;

            try
            {
                _objectsMap = (Dictionary<string, UIElement>)GraphicsWindowType.GetField("_objectsMap", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase).GetValue(null);
                if (!_objectsMap.TryGetValue("_turtle", out obj))
                {
                    _initialized = (bool)TurtleType.GetField("_initialized", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase).GetValue(null);
                    TurtleType.GetField("_initialized", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase).SetValue(_initialized, false);
                    Turtle.Show();
                };
            }
            catch
            {
            }
        }

        /// <summary>
        /// Pause GraphicsWindow Updates.
        /// </summary>
        /// <returns>
        /// None.
        /// </returns>
        public static void PauseUpdates()
        {
            IntPtr _hWnd = FindWindow(null, GraphicsWindow.Title);
            SendMessage(_hWnd, WM_SETREDRAW, false, 0);
        }

        /// <summary>
        /// Resume GraphicsWindow Updates.
        /// </summary>
        /// <returns>
        /// None.
        /// </returns>
        public static void ResumeUpdates()
        {
            IntPtr _hWnd = FindWindow(null, GraphicsWindow.Title);
            SendMessage(_hWnd, WM_SETREDRAW, true, 0);
            GraphicsWindow.GetPixel(0,0); //Forces a redraw
        }

        /// <summary>
        /// Moves a line shape.
        /// </summary>
        /// <param name="shapeName">
        /// The shape name (a line created with Shapes.AddLine).
        /// </param>
        /// <param name="x1">
        /// The first X coordinate to move the line to.
        /// </param>
        /// <param name="y1">
        /// The first Y coordinate to move the line to.
        /// </param>
        /// <param name="x2">
        /// The second X coordinate to move the line to.
        /// </param>
        /// <param name="y2">
        /// The second Y coordinate to move the line to.
        /// </param>
        /// <returns>
        /// "True" or "False".
        /// </returns>
        public static Primitive MoveLine(Primitive shapeName, Primitive x1, Primitive y1, Primitive x2, Primitive y2)
        {

            Type GraphicsWindowType = typeof(GraphicsWindow);
            Dictionary<string, UIElement> _objectsMap;
            UIElement obj;

            try
            {
                _objectsMap = (Dictionary<string, UIElement>)GraphicsWindowType.GetField("_objectsMap", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase).GetValue(null);
                if (!_objectsMap.TryGetValue((string)shapeName, out obj))
                {
                    return "False";
                };

                InvokeHelperWithReturn ret = new InvokeHelperWithReturn(delegate
                {
                    try
                    {
                        Line shape = (Line)obj;
                        shape.X1 = x1;
                        shape.X2 = x2;
                        shape.Y1 = y1;
                        shape.Y2 = y2;
                        return "True";
                    }
                    catch
                    {
                        return "False";
                    }
                });
                MethodInfo method = GraphicsWindowType.GetMethod("InvokeWithReturn", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase);
                return method.Invoke(null, new object[] { ret }).ToString();
            }
            catch
            {
                return "False";
            }
        }

        /// <summary>
        /// Checks for shape overlap of bounding boxes (collision detection).
        /// </summary>
        /// <param name="shape1">
        /// The first shape name.
        /// </param>
        /// <param name="shape2">
        /// The second shape name.
        /// </param>
        /// <returns>
        /// "True" or "False".
        /// </returns>
        public static Primitive OverlapBox(Primitive shape1, Primitive shape2)
        {

            Type GraphicsWindowType = typeof(GraphicsWindow);
            Dictionary<string, UIElement> _objectsMap;
            UIElement obj1, obj2;

            try
            {
                _objectsMap = (Dictionary<string, UIElement>)GraphicsWindowType.GetField("_objectsMap", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase).GetValue(null);
                if (!_objectsMap.TryGetValue((string)shape1, out obj1) || !_objectsMap.TryGetValue((string)shape2, out obj2))
                {
                    return "False";
                };

                InvokeHelperWithReturn ret = new InvokeHelperWithReturn(delegate
                {
                    try
                    {
                        Rect rect1 = new Rect(obj1.RenderSize);
                        Rect rect2 = new Rect(obj2.RenderSize);
                        rect1.Offset(System.Windows.Media.VisualTreeHelper.GetOffset(obj1));
                        rect2.Offset(System.Windows.Media.VisualTreeHelper.GetOffset(obj2));

                        if (rect1.IntersectsWith(rect2))
                        {
                            return "True";
                        }
                        else
                        {
                            return "False";
                        }
                    }
                    catch
                    {
                        return "False";
                    }
                });
                MethodInfo method = GraphicsWindowType.GetMethod("InvokeWithReturn", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase);
                return method.Invoke(null, new object[] { ret }).ToString();
            }
            catch
            {
                return "False";
            }
        }

        /// <summary>
        /// Checks for shape overlap of bounding circles (collision detection).
        /// </summary>
        /// <param name="shape1">
        /// The first shape name.
        /// </param>
        /// <param name="shape2">
        /// The second shape name.
        /// </param>
        /// <returns>
        /// "True" or "False".
        /// </returns>
        public static Primitive OverlapCircle(Primitive shape1, Primitive shape2)
        {

            Type GraphicsWindowType = typeof(GraphicsWindow);
            Dictionary<string, UIElement> _objectsMap;
            UIElement obj1, obj2;

            try
            {
                _objectsMap = (Dictionary<string, UIElement>)GraphicsWindowType.GetField("_objectsMap", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase).GetValue(null);
                if (!_objectsMap.TryGetValue((string)shape1, out obj1) || !_objectsMap.TryGetValue((string)shape2, out obj2))
                {
                    return "False";
                };

                InvokeHelperWithReturn ret = new InvokeHelperWithReturn(delegate
                {
                    try
                    { 
                        Rect rect1 = new Rect(obj1.RenderSize);
                        Rect rect2 = new Rect(obj2.RenderSize);
                        rect1.Offset(System.Windows.Media.VisualTreeHelper.GetOffset(obj1));
                        rect2.Offset(System.Windows.Media.VisualTreeHelper.GetOffset(obj2));

                        double rad1 = System.Math.Sqrt(rect1.Width * rect1.Width + rect1.Height * rect1.Height) / 4.0;
                        double rad2 = System.Math.Sqrt(rect2.Width * rect2.Width + rect2.Height * rect2.Height) / 4.0;
                        double dx = (rect1.X + rect1.Width / 2.0) - (rect2.X + rect2.Width / 2.0);
                        double dy = (rect1.Y + rect1.Height / 2.0) - (rect2.Y + rect2.Height / 2.0);
                        double dist = System.Math.Sqrt(dx * dx + dy * dy);

                        if (dist <= rad1+rad2)
                        {
                            return "True";
                        }
                        else
                        {
                            return "False";
                        }
                    }
                    catch
                    {
                        return "False";
                    }
                });
                MethodInfo method = GraphicsWindowType.GetMethod("InvokeWithReturn", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase);
                return method.Invoke(null, new object[] { ret }).ToString();
            }
            catch
            {
                return "False";
            }
        }

        /// <summary>
        /// Set shape Brush colour.
        /// </summary>
        /// <param name="shapeName">
        /// The shape name.
        /// </param>
        /// <param name="colour">
        /// The new brush colour.
        /// </param>
        /// <returns>
        /// "True" or "False".
        /// </returns>
        public static Primitive BrushColour(Primitive shapeName, Primitive colour)
        {

            Type GraphicsWindowType = typeof(GraphicsWindow);
            Dictionary<string, UIElement> _objectsMap;
            UIElement obj;

            try
            {
                _objectsMap = (Dictionary<string, UIElement>)GraphicsWindowType.GetField("_objectsMap", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase).GetValue(null);
                if (!_objectsMap.TryGetValue((string)shapeName, out obj))
                {
                    return "False";
                };

                InvokeHelperWithReturn ret = new InvokeHelperWithReturn(delegate
                {
                    try
                    {
                        Ellipse shape = (Ellipse)obj;
                        shape.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString(colour));
                        return "True";
                    }
                    catch
                    {
                    }
                    try
                    {
                        Rectangle shape = (Rectangle)obj;
                        shape.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString(colour));
                        return "True";
                    }
                    catch
                    {
                    }
                    try
                    {
                        Polygon shape = (Polygon)obj;
                        shape.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString(colour));
                        return "True";
                    }
                    catch
                    {
                    }
                    return "False";
                });
                MethodInfo method = GraphicsWindowType.GetMethod("InvokeWithReturn", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase);
                return method.Invoke(null, new object[] { ret }).ToString();
            }
            catch
            {
                return "False";
            }
        }

        /// <summary>
        /// Set shape Pen colour.
        /// </summary>
        /// <param name="shapeName">
        /// The shape name.
        /// </param>
        /// <param name="colour">
        /// The new pen colour.
        /// </param>
        /// <returns>
        /// "True" or "False".
        /// </returns>
        public static Primitive PenColour(Primitive shapeName, Primitive colour)
        {

            Type GraphicsWindowType = typeof(GraphicsWindow);
            Dictionary<string, UIElement> _objectsMap;
            UIElement obj;

            try
            {
                _objectsMap = (Dictionary<string, UIElement>)GraphicsWindowType.GetField("_objectsMap", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase).GetValue(null);
                if (!_objectsMap.TryGetValue((string)shapeName, out obj))
                {
                    return "False";
                };

                InvokeHelperWithReturn ret = new InvokeHelperWithReturn(delegate
                {
                    try
                    {
                        Ellipse shape = (Ellipse)obj;
                        shape.Stroke = new SolidColorBrush((Color)ColorConverter.ConvertFromString(colour));
                        return "True";
                    }
                    catch
                    {
                    }
                    try
                    {
                        Rectangle shape = (Rectangle)obj;
                        shape.Stroke = new SolidColorBrush((Color)ColorConverter.ConvertFromString(colour));
                        return "True";
                    }
                    catch
                    {
                    }
                    try
                    {
                        Polygon shape = (Polygon)obj;
                        shape.Stroke = new SolidColorBrush((Color)ColorConverter.ConvertFromString(colour));
                        return "True";
                    }
                    catch
                    {
                    }
                    try
                    {
                        Line shape = (Line)obj;
                        shape.Stroke = new SolidColorBrush((Color)ColorConverter.ConvertFromString(colour));
                        return "True";
                    }
                    catch
                    {
                    }
                    return "False";
                });
                MethodInfo method = GraphicsWindowType.GetMethod("InvokeWithReturn", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase);
                return method.Invoke(null, new object[] { ret }).ToString();
            }
            catch
            {
                return "False";
            }
        }

        /// <summary>
        /// Set shape Pen width.
        /// </summary>
        /// <param name="shapeName">
        /// The shape name.
        /// </param>
        /// <param name="width">
        /// The new pen width.
        /// </param>
        /// <returns>
        /// "True" or "False".
        /// </returns>
        public static Primitive PenWidth(Primitive shapeName, Primitive width)
        {

            Type GraphicsWindowType = typeof(GraphicsWindow);
            Dictionary<string, UIElement> _objectsMap;
            UIElement obj;

            try
            {
                _objectsMap = (Dictionary<string, UIElement>)GraphicsWindowType.GetField("_objectsMap", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase).GetValue(null);
                if (!_objectsMap.TryGetValue((string)shapeName, out obj))
                {
                    return "False";
                };

                InvokeHelperWithReturn ret = new InvokeHelperWithReturn(delegate
                {
                    try
                    {
                        Ellipse shape = (Ellipse)obj;
                        shape.StrokeThickness = width;
                        return "True";
                    }
                    catch
                    {
                    }
                    try
                    {
                        Rectangle shape = (Rectangle)obj;
                        shape.StrokeThickness = width;
                        return "True";
                    }
                    catch
                    {
                    }
                    try
                    {
                        Polygon shape = (Polygon)obj;
                        shape.StrokeThickness = width;
                        return "True";
                    }
                    catch
                    {
                    }
                    try
                    {
                        Line shape = (Line)obj;
                        shape.StrokeThickness = width;
                        return "True";
                    }
                    catch
                    {
                    }
                    return "False";
                });
                MethodInfo method = GraphicsWindowType.GetMethod("InvokeWithReturn", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase);
                return method.Invoke(null, new object[] { ret }).ToString();
            }
            catch
            {
                return "False";
            }
        }

        /// <summary>
        /// Set shape Pen style (dash, dot etc).
        /// </summary>
        /// <param name="shapeName">
        /// The shape name.
        /// </param>
        /// <param name="dash">
        /// The dash length.
        /// </param>
        /// <param name="space">
        /// The space length.
        /// </param>
        /// <returns>
        /// "True" or "False".
        /// </returns>
        public static Primitive PenStyle(Primitive shapeName, Primitive dash, Primitive space)
        {

            Type GraphicsWindowType = typeof(GraphicsWindow);
            Dictionary<string, UIElement> _objectsMap;
            UIElement obj;

            try
            {
                _objectsMap = (Dictionary<string, UIElement>)GraphicsWindowType.GetField("_objectsMap", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase).GetValue(null);
                if (!_objectsMap.TryGetValue((string)shapeName, out obj))
                {
                    return "False";
                };

                InvokeHelperWithReturn ret = new InvokeHelperWithReturn(delegate
                {
                    try
                    {
                        Ellipse shape = (Ellipse)obj;
                        DoubleCollection style = new DoubleCollection();
                        style.Add(dash);
                        style.Add(space);
                        shape.StrokeDashArray = style;
                        return "True";
                    }
                    catch
                    {
                    }
                    try
                    {
                        Rectangle shape = (Rectangle)obj;
                        DoubleCollection style = new DoubleCollection();
                        style.Add(dash);
                        style.Add(space);
                        shape.StrokeDashArray = style;
                        return "True";
                    }
                    catch
                    {
                    }
                    try
                    {
                        Polygon shape = (Polygon)obj;
                        DoubleCollection style = new DoubleCollection();
                        style.Add(dash);
                        style.Add(space);
                        shape.StrokeDashArray = style;
                        return "True";
                    }
                    catch
                    {
                    }
                    try
                    {
                        Line shape = (Line)obj;
                        DoubleCollection style = new DoubleCollection();
                        style.Add(dash);
                        style.Add(space);
                        shape.StrokeDashArray = style;
                        return "True";
                    }
                    catch
                    {
                    }
                    return "False";
                });
                MethodInfo method = GraphicsWindowType.GetMethod("InvokeWithReturn", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase);
                return method.Invoke(null, new object[] { ret }).ToString();
            }
            catch
            {
                return "False";
            }
        }

        /// <summary>
        /// Set shape z index (layer position negative are background and positive are foreground - default 0).
        /// </summary>
        /// <param name="shapeName">
        /// The shape name.
        /// </param>
        /// <param name="z_index">
        /// The z-index (zero, positive or negative interger).
        /// </param>
        /// <returns>
        /// "True" or "False".
        /// </returns>
        public static Primitive ZIndex(Primitive shapeName, Primitive z_index)
        {

            Type GraphicsWindowType = typeof(GraphicsWindow);
            Dictionary<string, UIElement> _objectsMap;
            UIElement obj;

            try
            {
                _objectsMap = (Dictionary<string, UIElement>)GraphicsWindowType.GetField("_objectsMap", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase).GetValue(null);
                if (!_objectsMap.TryGetValue((string)shapeName, out obj))
                {
                    return "False";
                };

                InvokeHelperWithReturn ret = new InvokeHelperWithReturn(delegate
                {
                    try
                    {
                        Canvas.SetZIndex(obj, z_index);
                        return "True";
                    }
                    catch
                    {
                    }
                    return "False";
                });
                MethodInfo method = GraphicsWindowType.GetMethod("InvokeWithReturn", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase);
                return method.Invoke(null, new object[] { ret }).ToString();
            }
            catch
            {
                return "False";
            }
        }
    }
}
