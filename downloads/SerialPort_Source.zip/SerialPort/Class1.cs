﻿// Microsoft Small Basic - Serial Port extension by Nino Carrillo
using System;
using System.IO.Ports;
using Microsoft.SmallBasic.Library;


namespace SmallBasicSerialPort
{
    /// <summary>
    /// Sends and receives data over the serial port
    /// </summary>
    [SmallBasicType]
    public static class CommPort
    {
        static SerialPort _tty;
        static string _portname;

        /// <summary>
        /// Opens a serial port for use.  Assumes 8 databits, no parity.
        /// </summary>
        /// <param name="portname">
        /// String identifying which port to open in the form of "COM8".  If the passed string is invalid or the port doesn't exist, the highest available port is opened.
        /// </param>
        /// <param name="baudrate">
        /// Integer baud rate
        /// </param>
        public static void OpenPort(Primitive portname, Primitive baudrate)
        {
            string[] portnames;
            _portname = (string)portname;
            portnames = SerialPort.GetPortNames();
            _portname = _portname.ToUpper();

            if (System.Array.Exists(portnames, ComparePortName) == false)
            {
                _portname = portnames[portnames.Length - 1];
            }
            baudrate = (int)baudrate;

            _tty = new SerialPort(_portname, baudrate, Parity.None, 8, StopBits.One);
            _tty.Open();
        }

        /// <summary>
        /// Reads one byte from the open serial port and returns that byte as an integer
        /// </summary>
        /// <returns>
        /// One integer value between 0 and 255.
        /// </returns>
        public static Primitive RXByte()
        {
            Primitive bytedata;
            bytedata = _tty.ReadByte();
            return bytedata;
        }

        /// <summary>
        /// Reads one byte from the open serial port and returns that byte as a unicode character
        /// </summary>
        /// <returns>
        /// One unicode character.
        /// </returns>
        public static Primitive RXChar()
        {
            Primitive chardata;
            char c;
            string s;

            c = (char)_tty.ReadByte();
            s = Convert.ToString(c);
            chardata = s;
            return chardata;
        }
        /// <summary>
        /// Reads all available bytes in the open comm port input buffer.
        /// </summary>
        /// <returns>
        /// Returns an array of bytes.
        /// </returns>
        public static Primitive RXAll()
        {
            return _tty.ReadExisting();
        }
        /// <summary>
        /// Closes the open serial port.
        /// </summary>
        public static void ClosePort()
        {
            _tty.Close();
        }

        /// <summary>
        /// Returns a list of available serial ports.
        /// </summary>
        /// <returns>
        /// A string containing the names of available serial ports.
        /// </returns>
        public static Primitive AvailablePorts()
        {
            Primitive portlist = "";
            string[] portnames;
            portnames = SerialPort.GetPortNames();
            foreach (string s in portnames)
            {
                portlist = portlist + s + " ";
            }
            return portlist;
        }

        /// <summary>
        /// Sends one byte to the serial port.
        /// </summary>
        /// <param name="databyte">
        /// The byte to be written to the port.
        /// </param>
        public static void TXByte(Primitive databyte)
        {
            byte[] b = { (byte)databyte };
            _tty.Write(b, 0, 1);
        }
        /// <summary>
        /// Sends a string to the serial port.
        /// </summary>
        /// <param name="datastring">
        /// String value to be sent.
        /// </param>

        public static void TXString(Primitive datastring)
        {
            string s = datastring;
            _tty.Write(s);
        }

        /// <summary>
        /// Sets or clears hardware flow control.
        /// </summary>
        /// <param name="handshake">
        /// "H" or "h" to select hardware flow control, any other character to clear.
        /// </param>

        public static void SetHandshake(Primitive handshake)
        {
            string _handshake;
            _handshake = (string)handshake;
            _handshake = _handshake.ToUpper();
            if (_handshake == "H")
            {
                _tty.Handshake = Handshake.RequestToSend;
            }
            else
            {
                _tty.Handshake = Handshake.None;
            }
        }

        private static bool ComparePortName(String s)
        {
            if (s == _portname)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
