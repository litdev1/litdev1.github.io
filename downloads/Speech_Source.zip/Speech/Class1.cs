﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Serialization.Formatters.Binary;

using Microsoft.SmallBasic.Library;
using System.Speech.Synthesis;

namespace SpeechExtension
{
    /// <summary>
    /// The Speech library allows text to be spoken.
    /// </summary>
    [SmallBasicType]
    public static class Speech
    {
        static Primitive _speed = new Primitive();

        /// <summary>
        /// Sets the speech speed.
        /// </summary>
        /// <param name="speed">
        /// Speed of speech (-10 to 10).
        /// </param>
        /// <returns>
        /// None.
        /// </returns>
        public static Primitive Speed(Primitive speed)
        {
            _speed = speed;
            _speed = System.Math.Min(10, System.Math.Max(-10, _speed));
            return _speed;
        }

        /// <summary>
        /// Speak some text.
        /// </summary>
        /// <param name="text">
        /// Text to be spoken.
        /// </param>
        /// <returns>
        /// None.
        /// </returns>
        public static void Speak(Primitive text)
        {
            System.Speech.Synthesis.SpeechSynthesizer Speak = new SpeechSynthesizer();
            Speak.Rate = _speed;
            Speak.Speak(text);
        }
    }
}
