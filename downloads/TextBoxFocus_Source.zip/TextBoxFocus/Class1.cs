﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SmallBasic.Library;
using Microsoft.SmallBasic.Library.Internal;
using System.Windows;
using System.Reflection;

namespace TextBoxFocus
{
    /// <summary>
    /// TextBoxFocus utility.
    /// </summary>
    [SmallBasicType]
    public static class TextBoxFocus
    {
        /// <summary>
        /// Checks if the named shape has the focus.
        /// </summary>
        /// <param name="shapeName">
        /// The shape name (usually a textbox).
        /// </param>
        /// <returns>
        /// "True" or "False".
        /// </returns>
        public static Primitive IsFocus(Primitive shapeName)
        {

            Type GraphicsWindowType = typeof(GraphicsWindow);
            Dictionary<string, UIElement> _objectsMap;
            UIElement obj;

            try
            {
                _objectsMap = (Dictionary<string, UIElement>)GraphicsWindowType.GetField("_objectsMap", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase).GetValue(null);
                _objectsMap.TryGetValue((string)shapeName, out obj);

                InvokeHelperWithReturn ret = new InvokeHelperWithReturn(delegate { return obj.IsFocused; });
                MethodInfo method = GraphicsWindowType.GetMethod("InvokeWithReturn", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase);
                return method.Invoke(null, new object[] { ret }).ToString();
            }
            catch
            {
                return "False";
            }
        }

        /// <summary>
        /// Sets the named shape to have focus.
        /// </summary>
        /// <param name="shapeName">
        /// The shape name (usually a textbox).
        /// </param>
        /// <returns>
        /// "True" or "False" depending on success or failure.
        /// </returns>
        public static Primitive SetFocus(Primitive shapeName)
        {

            Type GraphicsWindowType = typeof(GraphicsWindow);
            Dictionary<string, UIElement> _objectsMap;
            UIElement obj;

            try
            {
                _objectsMap = (Dictionary<string, UIElement>)GraphicsWindowType.GetField("_objectsMap", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase).GetValue(null);
                _objectsMap.TryGetValue((string)shapeName, out obj);

                InvokeHelperWithReturn ret = new InvokeHelperWithReturn(delegate { return obj.Focus(); });
                MethodInfo method = GraphicsWindowType.GetMethod("InvokeWithReturn", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase);
                return method.Invoke(null, new object[] { ret }).ToString();
            }
            catch
            {
                return "False";
            }
        }

        /// <summary>
        /// Gets the shape that has current focus.
        /// </summary>
        /// <returns>
        /// The shape name (usually a textbox) or "False".
        /// </returns>
        public static Primitive GetFocus()
        {

            Type GraphicsWindowType = typeof(GraphicsWindow);
            Dictionary<string, UIElement> _objectsMap;
            UIElement obj;
            string shapeName;

            try
            {
                _objectsMap = (Dictionary<string, UIElement>)GraphicsWindowType.GetField("_objectsMap", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase).GetValue(null);

                foreach (KeyValuePair<String, UIElement> entry in _objectsMap)
                {
                    shapeName = entry.Key;
                    _objectsMap.TryGetValue((string)shapeName, out obj);

                    InvokeHelperWithReturn ret = new InvokeHelperWithReturn(delegate { return obj.IsFocused; });
                    MethodInfo method = GraphicsWindowType.GetMethod("InvokeWithReturn", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.IgnoreCase);
                    if (method.Invoke(null, new object[] { ret }).ToString() == "True")
                    {
                        return shapeName;
                    }
                }
                return "False";
            }
            catch
            {
                return "False";
            }
        }
    }
}
