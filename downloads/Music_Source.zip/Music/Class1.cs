﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SmallBasic.Library;
using System.Windows.Media;
using System.Windows;
using System.Threading;

namespace Music
{
    /// <summary>
    /// Music file utility.
    /// </summary>
    [SmallBasicType]
    public static class MusicFile
    {
        /// <summary>
        /// Gets the play time for a music file.
        /// </summary>
        /// <param name="filePath">
        /// The full path of the music file e.g. "C:\Users\Public\Music\song.mp3".
        /// </param>
        /// <returns>
        /// The file play time in seconds (0 if failed).
        /// </returns>
        public static Primitive PlayTime(Primitive filePath)
        {
		    try
		    {
			    MediaPlayer mediaPlayer = new MediaPlayer();
			    Uri uri = new Uri(filePath);
			    mediaPlayer.Open(uri);
			    //Wait for the player to open the file (up to 1 sec)
			    int iCount = 0;
			    while (!mediaPlayer.NaturalDuration.HasTimeSpan && iCount < 100)
			    {
				    Thread.Sleep(10);
				    iCount++;
			    }
			    Duration duration = mediaPlayer.NaturalDuration;
			    int sec =  duration.TimeSpan.Minutes*60+duration.TimeSpan.Seconds+1; //Round up
			    mediaPlayer.Close();
			    return sec;
		    }
		    catch
		    {
		    }

		    return 0;
        }
    }
}
