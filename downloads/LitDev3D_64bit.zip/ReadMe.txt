3D library for SmallBasic based on IrrLicht Engine
==================================================

Since this library is C++, currently only 64 bit PCs (Windows 7 probably) works.  

As usual copy all the required dlls to the SmallBasic lib folder.

The basic sample and intellisense should get you started.

This is very ealy stages and there may be problems and possibilities for game-play are relatively limited - suggestions/problems welcome.

Also check out the irrlicht site for some background info or dowloads to build your own native C++ game - they have a pretty good set of example solutions showing what can be done.  I did have to make some changes to prevent Direct3D (only old versions supported) from failing to build.

UPDATES
=======

6] Get and Set objection type descriptions.

5] Billboard and camera properties added.

4] Specular highlights and improved flame lights.

3] Some improved light handling, ambient background, lights and glowing objects.

2] Collision and mouse click event added

1] Hopefully works on 32 and 64 bit systems with no special dll copying required


