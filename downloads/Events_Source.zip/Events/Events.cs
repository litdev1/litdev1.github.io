﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SmallBasic.Library;
using System.Windows.Input;

namespace Events
{
    /// <summary>
    /// Test Events.
    /// </summary>
    [SmallBasicType]
    public static class EventTest
    {
        // This is the SmallBasic delegate
        private static SmallBasicCallback _DisplaySettingsDelegate;

        // Event subroutine calls the SmallBasic delegate 
        private static void _DisplaySettingsEvent(Object sender, EventArgs e)
        {
            _DisplaySettingsDelegate();
        }

        // Start event and set SmallBasic callback delegate
        private static SmallBasicCallback _DisplaySettings
        {
            get
            {
                return _DisplaySettingsDelegate;
            }
            set
            {
                _DisplaySettingsDelegate = value;
                Microsoft.Win32.SystemEvents.DisplaySettingsChanged += new EventHandler(_DisplaySettingsEvent);
            }
        }

        /// <summary>
        /// Event when the display settings change (such as screen resolution).
        /// </summary>
        public static event SmallBasicCallback DisplaySettings
        {
            add
            {
                _DisplaySettings = null;
                _DisplaySettings = (SmallBasicCallback)Delegate.Combine(_DisplaySettings, value);
            }
            remove
            {
                _DisplaySettings = (SmallBasicCallback)Delegate.Remove(_DisplaySettings, value);
            }
        }

    }
}
