﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Principal;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using System.Collections;
using System.Threading;
using System.Xml;
using System.Reflection;
using Microsoft.SmallBasic.Library;

namespace LitDevUtilities
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            bMyUser = CalculateMD5Hash(WindowsIdentity.GetCurrent().Name) == "30033810F853C34F952DBAD250E25755";
            linkLabel1.LinkClicked += new LinkLabelLinkClickedEventHandler(LinkedLabelClicked);

            //XML Converter
            checkBoxSeparateFiles.Checked = Properties.Settings.Default.files;
            checkBoxHTML.Checked = Properties.Settings.Default.html;
            checkBoxRTF.Checked = Properties.Settings.Default.rtf;
            checkBoxCSS.Checked = Properties.Settings.Default.css;
            checkBoxImages.Checked = Properties.Settings.Default.images;
            comboBoxRTF.SelectedIndex = Properties.Settings.Default.size;
            comboBoxRTF.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxCases.DropDownStyle = ComboBoxStyle.DropDownList;
            textBoxXML.Text = Properties.Settings.Default.XMLFolder;
            textBoxHTML.Text = Properties.Settings.Default.HTMLFolder;
            textBoxRTF.Text = Properties.Settings.Default.RTFFolder;
            if (textBoxXML.Text == "")
            {
                if (IntPtr.Size == 8)
                {
                    textBoxXML.Text = "C:\\Program Files (x86)\\Microsoft\\Small Basic\\lib";
                }
                else
                {
                    textBoxXML.Text = "C:\\Program Files\\Microsoft\\Small Basic\\lib";
                }
            }
            if (textBoxHTML.Text == "") textBoxHTML.Text = textBoxXML.Text;
            if (textBoxRTF.Text == "") textBoxRTF.Text = textBoxXML.Text;

            //File Searcher
            textBoxRoot.Text = Properties.Settings.Default.RootFolder;
            listViewSearcher.View = View.Details;
            lvwColumnSorter = new ListViewColumnSorter();
            listViewSearcher.ListViewItemSorter = lvwColumnSorter;

            //Links

            //Extensions
        }

        private void OnClosing(object sender, FormClosingEventArgs e)
        {
            //XML Converter
            Properties.Settings.Default.files = checkBoxSeparateFiles.Checked;
            Properties.Settings.Default.XMLFolder = textBoxXML.Text;
            Properties.Settings.Default.HTMLFolder = textBoxHTML.Text;
            Properties.Settings.Default.RTFFolder = textBoxRTF.Text;
            Properties.Settings.Default.DefaultExtension = (null == comboBoxCases.SelectedItem) ? "" : comboBoxCases.SelectedItem.ToString();
            Properties.Settings.Default.html = checkBoxHTML.Checked;
            Properties.Settings.Default.rtf = checkBoxRTF.Checked;
            Properties.Settings.Default.css = checkBoxCSS.Checked;
            Properties.Settings.Default.images = checkBoxImages.Checked;
            Properties.Settings.Default.size = comboBoxRTF.SelectedIndex;

            //File Searcher
            Properties.Settings.Default.RootFolder = textBoxRoot.Text;

            Properties.Settings.Default.Save();
        }
        private static bool showErrors = false;

        #region XML Conversion

        Parser parser = null;
        List<string> exclude = new List<string>();
        List<Group> groups = null;
        bool bMyUser;

        private string CalculateMD5Hash(string input)
        {
            MD5 md5 = MD5.Create();
            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
            byte[] hash = md5.ComputeHash(inputBytes);

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                sb.Append(hash[i].ToString("X2"));
            }
            return sb.ToString();
        }

        private void LinkedLabelClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linkLabel1.LinkVisited = true;
            System.Diagnostics.Process.Start("http://www.litdev.co.uk");    
        }
    
        private void buttonConvert_Click(object sender, EventArgs e)
        {
            this.UseWaitCursor = true;
            progressBarXML.Value = 0;
            if (null == comboBoxCases.SelectedItem) return;
            if (null == parser) return;
            if (null == groups) return;
            CheckedListBox.CheckedItemCollection excludeUser = checkedListBoxExclude.CheckedItems;
            for (int i = groups.Count - 1; i >= 0; i--)
            {
                Group group1 = groups[i];
                //User exclusions
                foreach (string ex in excludeUser)
                {
                    if (group1.member.header.text.ToLower() == ex.ToLower()) groups.Remove(group1);
                }
            }
            progressBarXML.PerformStep();

            if (checkBoxHTML.Checked)
            {
                if (Directory.Exists(textBoxHTML.Text))
                {
                    string htmlFile = textBoxHTML.Text + "\\" + comboBoxCases.SelectedItem + ".html";
                    parser.writeHTML(htmlFile, bMyUser, checkBoxSeparateFiles.Checked);
                }
            }
            progressBarXML.PerformStep();

            if (checkBoxRTF.Checked)
            {
                if (Directory.Exists(textBoxRTF.Text))
                {
                    string rtfFile = textBoxRTF.Text + "\\" + comboBoxCases.SelectedItem + ".rtf";
                    parser.writeRTF(rtfFile, comboBoxRTF.SelectedIndex);
                }
            }
            progressBarXML.PerformStep();

            if (checkBoxCSS.Checked)
            {
                if (Directory.Exists(textBoxHTML.Text))
                {
                    string css = global::LitDevUtilities.Properties.Resources.styleAPI;
                    StreamWriter sw = parser.getStreamWriter(textBoxHTML.Text + "\\styleAPI.css", Encoding.ASCII);
                    if (null == sw) return;
                    sw.WriteLine(css);
                    sw.Close();
                }
            }
            progressBarXML.PerformStep();

            if (checkBoxImages.Checked)
            {
                if (Directory.Exists(textBoxHTML.Text))
                {
                    if (!Directory.Exists(textBoxHTML.Text + "\\images"))
                    {
                        Directory.CreateDirectory(textBoxHTML.Text + "\\images");
                    }
                    System.Drawing.Bitmap dImg;
                    System.Drawing.Icon dIcon;
                    FileStream fs;

                    try
                    {
                        dImg = global::LitDevUtilities.Properties.Resources.background;
                        fs = new FileStream(textBoxHTML.Text + "\\images\\background.png", FileMode.Create);
                        dImg.Save(fs, System.Drawing.Imaging.ImageFormat.Png);
                        fs.Close();

                        dImg = global::LitDevUtilities.Properties.Resources.IntellisenseEvent;
                        fs = new FileStream(textBoxHTML.Text + "\\images\\IntellisenseEvent.png", FileMode.Create);
                        dImg.Save(fs, System.Drawing.Imaging.ImageFormat.Png);
                        fs.Close();

                        dImg = global::LitDevUtilities.Properties.Resources.IntellisenseMethod;
                        fs = new FileStream(textBoxHTML.Text + "\\images\\IntellisenseMethod.png", FileMode.Create);
                        dImg.Save(fs, System.Drawing.Imaging.ImageFormat.Png);
                        fs.Close();

                        dImg = global::LitDevUtilities.Properties.Resources.IntellisenseObject;
                        fs = new FileStream(textBoxHTML.Text + "\\images\\IntellisenseObject.png", FileMode.Create);
                        dImg.Save(fs, System.Drawing.Imaging.ImageFormat.Png);
                        fs.Close();

                        dImg = global::LitDevUtilities.Properties.Resources.IntellisenseProperty;
                        fs = new FileStream(textBoxHTML.Text + "\\images\\IntellisenseProperty.png", FileMode.Create);
                        dImg.Save(fs, System.Drawing.Imaging.ImageFormat.Png);
                        fs.Close();

                        dIcon = global::LitDevUtilities.Properties.Resources.SBIcon;
                        fs = new FileStream(textBoxHTML.Text + "\\favicon.ico", FileMode.Create);
                        dIcon.Save(fs);
                        fs.Close();
                    }
                    catch (Exception ex)
                    {
                        if (showErrors) MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
                    }
                }
            }
            progressBarXML.PerformStep();
            this.UseWaitCursor = false;
        }

        private void textBoxXML_TextChanged(object sender, EventArgs e)
        {
            setExtensions();
        }

        private void setExtensions()
        {
            progressBarXML.Value = 0;
            try
            {
                comboBoxCases.Items.Clear();
                checkedListBoxExclude.Items.Clear();
                if (!Directory.Exists(textBoxXML.Text)) return;
                string[] files = Directory.GetFiles(textBoxXML.Text);
                foreach (string file in files)
                {
                    if (Path.GetExtension(file).ToLower() == ".xml") comboBoxCases.Items.Add(Path.GetFileNameWithoutExtension(file));
                }
                comboBoxCases.SelectedItem = Properties.Settings.Default.DefaultExtension;
                if (null == comboBoxCases.SelectedItem && comboBoxCases.Items.Count > 0) comboBoxCases.SelectedItem = comboBoxCases.SelectedIndex = 0;
                setExclusions();
            }
            catch (Exception ex)
            {
                        if (showErrors) MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
            }
        }

        private void setExclusions()
        {
            checkedListBoxExclude.Items.Clear();
            if (null == comboBoxCases.SelectedItem) return;

            try
            {
                exclude.Clear();
                //LitDev
                exclude.Add("LDWeather");
                exclude.Add("Capture");
                exclude.Add("Defines");
                exclude.Add("FIP");
                //LitDev3D
                exclude.Add("Resources");
                //SmallBasicLibrary
                exclude.Add("DiscoveryCompletedEventArgs");
                exclude.Add("DiscoveryCompletedEventHandler");
                exclude.Add("Keywords");
                exclude.Add("NativeHelper");
                exclude.Add("QueryCompletedEventArgs");
                exclude.Add("QueryCompletedEventHandler");
                exclude.Add("RegistrationCompletedEventArgs");
                exclude.Add("RegistrationCompletedEventHandler");
                exclude.Add("RestHelper");
                exclude.Add("SmallBasicApplication");
                exclude.Add("SmallBasicCallback");
                exclude.Add("StatusCompletedEventArgs");
                exclude.Add("StatusCompletedEventHandler");
                exclude.Add("Primitive");
                exclude.Add("Platform");
                exclude.Add("OfficeResearch");
                string xmlFile = textBoxXML.Text + "\\" + comboBoxCases.SelectedItem + ".xml";
                if (!System.IO.File.Exists(xmlFile)) return;
                parser = new Parser(xmlFile, exclude, (string)comboBoxCases.SelectedItem);
                groups = parser.Parse();
                if (null != groups)
                {
                    foreach (Group group in groups)
                    {
                        checkedListBoxExclude.Items.Add(group.member.header.text);
                    }
                }
            }
            catch (Exception ex)
            {
                if (showErrors) MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
            }
        }

        private void ExtensionChanged(object sender, EventArgs e)
        {
            setExclusions();
        }

        private void buttonBrowseXML_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.RootFolder = Environment.SpecialFolder.Desktop;
            folderBrowserDialog1.SelectedPath = textBoxXML.Text;
            folderBrowserDialog1.Description = "Select the input folder (where the XML is located).";
            folderBrowserDialog1.ShowNewFolderButton = false;
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                textBoxXML.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void buttonBrowseHTML_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.RootFolder = Environment.SpecialFolder.Desktop;
            folderBrowserDialog1.SelectedPath = textBoxHTML.Text;
            folderBrowserDialog1.Description = "Select the output folder (where the HTML will be created).";
            folderBrowserDialog1.ShowNewFolderButton = true;
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                textBoxHTML.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void buttonBrowseRTF_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.RootFolder = Environment.SpecialFolder.Desktop;
            folderBrowserDialog1.SelectedPath = textBoxRTF.Text;
            folderBrowserDialog1.Description = "Select the output folder (where the RTF will be created).";
            folderBrowserDialog1.ShowNewFolderButton = false;
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                textBoxRTF.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void buttonHelpXML_Click(object sender, EventArgs e)
        {
            FormHelpXML help = new FormHelpXML();
            help.Show();
        }

        #endregion

        #region File Searcher

        Searcher searcher = null;
        string keyword;
        RichTextBoxFinds findMode;
        ListViewColumnSorter lvwColumnSorter;
        bool bLoaded = false;
        public static int progressBarSearcherValue;
        public static List<ListViewItem> listViewSearcherItems;

        private void threadSearch()
        {
            searcher = new Searcher(textBoxRoot.Text);
            listViewSearcherItems = new List<ListViewItem>();
            int i = 0;
            foreach (SBfile file in searcher.SBfiles)
            {
                ListViewItem item = new ListViewItem(new string[] { file.fileName, file.length.ToString(), file.date.ToString(), file.folder });
                item.SubItems[0].Tag = file.fileName;
                item.SubItems[1].Tag = file.length;
                item.SubItems[2].Tag = file.date;
                item.SubItems[3].Tag = file.folder;
                item.Tag = file;
                RegexOptions caseSensitive = checkBoxCase.Checked ? RegexOptions.None : RegexOptions.IgnoreCase;
                string wholeWord = checkBoxWholeWord.Checked ? "\\b" + keyword + "\\b" : keyword;
                bool isFound = Regex.IsMatch(string.Concat(file.text), wholeWord, caseSensitive);
                if (keyword == "" || file.file.ToLower().Contains(keyword.ToLower()) || isFound) listViewSearcherItems.Add(item);
                progressBarSearcherValue = 95 + (int)(5 * (++i) / (double)searcher.SBfiles.Count());
            }
            progressBarSearcherValue = 100;
        }

        private void setFiles()
        {
            if (!Directory.Exists(textBoxRoot.Text)) return;
            if (tabControl1.SelectedTab != tabControl1.TabPages[1]) return;
            this.UseWaitCursor = true;
            bLoaded = true;
            progressBarSearcher.Value = 0;
            richTextBoxPreview.Clear();
            textBoxKeyWordCount.Text = "";
            timer2.Start();
            Thread thread = new Thread(threadSearch);
            thread.Start();
        }

        private void buttonRoot_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.RootFolder = Environment.SpecialFolder.Desktop;
            folderBrowserDialog1.SelectedPath = textBoxRoot.Text;
            folderBrowserDialog1.Description = "Select the root folder for your Small Basic files.";
            folderBrowserDialog1.ShowNewFolderButton = false;
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                textBoxRoot.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void textBoxRoot_TextChanged(object sender, EventArgs e)
        {
            keyword = "";
            setFiles();
        }

        private void SearcherItemChanged(object sender, EventArgs e)
        {
            ListView view = (ListView)sender;
            if (view.SelectedItems.Count == 0) return;
            hScrollBar1.Value = view.SelectedItems[0].Index;
            ListViewItem item = (ListViewItem)view.SelectedItems[0];
            SBfile file = (SBfile)item.Tag;
            richTextBoxPreview.Clear();
            richTextBoxPreview.Lines = file.text.ToArray();

            if (keyword == "")
            {
                textBoxKeyWordCount.Text = "";
            }
            else
            {
                int pos = richTextBoxPreview.Find(keyword, findMode);
                int iCount = 0;
                while (pos >= 0)
                {
                    iCount++;
                    richTextBoxPreview.SelectionStart = pos;
                    richTextBoxPreview.SelectionLength = keyword.Length;
                    richTextBoxPreview.SelectionColor = Color.Red;
                    pos += keyword.Length;
                    pos = richTextBoxPreview.Find(keyword, pos, findMode);
                }
                textBoxKeyWordCount.Text = iCount.ToString() + (iCount == 1 ? " hit" : " hits");
            }
        }

        private void buttonFilter_Click(object sender, EventArgs e)
        {
            keyword = textBoxKeyword.Text;
            findMode = RichTextBoxFinds.None;
            if (checkBoxCase.Checked) findMode = findMode | RichTextBoxFinds.MatchCase;
            if (checkBoxWholeWord.Checked) findMode = findMode | RichTextBoxFinds.WholeWord;
            setFiles();
        }

        private void ColumnClick(object sender, ColumnClickEventArgs e)
        {
            // Determine if clicked column is already the column that is being sorted.
            if (e.Column == lvwColumnSorter.SortColumn)
            {
                // Reverse the current sort direction for this column.
                if (lvwColumnSorter.Order == SortOrder.Ascending)
                {
                    lvwColumnSorter.Order = SortOrder.Descending;
                }
                else
                {
                    lvwColumnSorter.Order = SortOrder.Ascending;
                }
            }
            else
            {
                // Set the column number that is to be sorted; default to ascending.
                lvwColumnSorter.SortColumn = e.Column;
                lvwColumnSorter.Order = SortOrder.Ascending;
            }

            // Perform the sort with these new sort options.
            listViewSearcher.Sort();
            if (listViewSearcher.SelectedItems.Count > 0) listViewSearcher.SelectedItems[0].EnsureVisible();
        }

        private void buttonOpen_Click(object sender, EventArgs e)
        {
            if (listViewSearcher.SelectedItems.Count == 0) return;
            string exe = "\"" + textBoxXML.Text.Substring(0, textBoxXML.Text.Length - 3) + "SB.exe" + "\"";
            string file = "\"" + ((SBfile)(listViewSearcher.SelectedItems[0].Tag)).file + "\"";
            try
            {
                System.Diagnostics.Process.Start(exe, file);
            }
            catch (Exception ex)
            {
                if (showErrors) MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
            }
        }

        private void buttonCopy_Click(object sender, EventArgs e)
        {
            if (listViewSearcher.SelectedItems.Count == 0) return;
            string file = ((SBfile)(listViewSearcher.SelectedItems[0].Tag)).file;
            Clipboard.SetText(file);
        }

        private void buttonRun_Click(object sender, EventArgs e)
        {
            if (listViewSearcher.SelectedItems.Count == 0) return;
            string exe = ((SBfile)(listViewSearcher.SelectedItems[0].Tag)).file;
            exe = "\"" + exe.Substring(0, exe.Length - 2) + "exe" + "\"";
            try
            {
                System.Diagnostics.Process.Start(exe);
            }
            catch (Exception ex)
            {
                if (showErrors) MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
            }
        }

        private void buttonCompile_Click(object sender, EventArgs e)
        {
            if (listViewSearcher.SelectedItems.Count == 0) return;
            string temp = Path.GetTempFileName();
            System.IO.File.Delete(temp);
            temp = temp.Substring(0, temp.Length - 4) + ".bat";
            string file = "\"" + ((SBfile)(listViewSearcher.SelectedItems[0].Tag)).file + "\"";
            string dir = "\"" + Path.GetDirectoryName(((SBfile)(listViewSearcher.SelectedItems[0].Tag)).file) + "\"";
            StreamWriter sw = parser.getStreamWriter(temp, Encoding.ASCII);
            if (null == sw) return;
            sw.WriteLine("cd " + dir);
            sw.WriteLine("\"" + textBoxXML.Text.Substring(0, textBoxXML.Text.Length - 3) + "SmallBasicCompiler.exe" + "\" " + file);
            sw.Close();
            try
            {
                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                proc.StartInfo = new System.Diagnostics.ProcessStartInfo(temp);
                proc.Start();
                proc.WaitForExit(10000);
            }
            catch (Exception ex)
            {
                if (showErrors) MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
            }
            System.IO.File.Delete(temp);
        }

        private void FilterKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) buttonFilter_Click(null, null);
        }

        private void SearcherScrollBarChanged(object sender, ScrollEventArgs e)
        {
            int index = ((HScrollBar)sender).Value;
            if (index >= 0 && index < listViewSearcher.Items.Count)
            {
                listViewSearcher.Items[index].Selected = true;
                listViewSearcher.EnsureVisible(index);
                listViewSearcher.Select();
            }
        }

        #endregion

        private void TabSelected(object sender, TabControlEventArgs e)
        {
            if (!bLoaded) //Use timer to give page time to load before initialising
            {
                timer1.Interval = 500;
                timer1.Start();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            setFiles();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            progressBarSearcher.Value = progressBarSearcherValue;
            Application.DoEvents();
            if (progressBarSearcherValue == 100)
            {
                listViewSearcher.Items.Clear();
                foreach (ListViewItem item in listViewSearcherItems)
                {
                    listViewSearcher.Items.Add(item);
                }
                foreach (ColumnHeader ch in this.listViewSearcher.Columns) ch.Width = -2;
                hScrollBar1.Maximum = listViewSearcher.Items.Count - 1;
                textBoxFileCount.Text = listViewSearcher.Items.Count + " files found";
                this.UseWaitCursor = false;
                timer2.Stop();
            }
        }

        #region Links

        int lastPage = 500;

        private void buttonForum_Click(object sender, EventArgs e)
        {
            this.UseWaitCursor = true;
            webBrowser1.Navigate("http://social.msdn.microsoft.com/Forums/en-US/smallbasic/threads");
            this.UseWaitCursor = false;
        }

        private void buttonWiki_Click(object sender, EventArgs e)
        {
            this.UseWaitCursor = true;
            webBrowser1.Navigate("http://social.technet.microsoft.com/wiki/tags/small+basic/en_2D00_US/default.aspx");
            this.UseWaitCursor = false;
        }

        private void buttonBlog_Click(object sender, EventArgs e)
        {
            this.UseWaitCursor = true;
            webBrowser1.Navigate("http://blogs.msdn.com/b/smallbasic/");
            this.UseWaitCursor = false;
        }

        private void buttonHome_Click(object sender, EventArgs e)
        {
            this.UseWaitCursor = true;
            webBrowser1.Navigate("http://msdn.microsoft.com/en-us/beginner/ff384126.aspx");
            this.UseWaitCursor = false;
        }

        private void buttonExtensions_Click(object sender, EventArgs e)
        {
            this.UseWaitCursor = true;
            webBrowser1.Navigate("http://blogs.msdn.com/b/smallbasic/archive/2012/10/12/small-basic-extensions-gallery.aspx");
            this.UseWaitCursor = false;
        }

        private void buttonCurriculum_Click(object sender, EventArgs e)
        {
            this.UseWaitCursor = true;
            webBrowser1.Navigate("http://social.technet.microsoft.com/wiki/contents/articles/16982.small-basic-curriculum-online.aspx");
            this.UseWaitCursor = false;
        }

        private void ForwardBackward(object sender, EventArgs e)
        {
            HScrollBar bar = (HScrollBar)sender;
            if (bar.Value > lastPage)
            {
                webBrowser1.GoForward();
            }
            else
            {
                webBrowser1.GoBack();
            }
            lastPage = bar.Value;
        }

        private void Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            webBrowser1.Focus();
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            if (null == webBrowser1.Url) return;
            webBrowser1.Refresh(WebBrowserRefreshOption.Completely);
        }

        #endregion

        #region Extensions

        List<SBLibrary> SBLibraries = new List<SBLibrary>();

        private void InitialiseLibraries()
        {
            progressBarAPI.Value = 5;
            SBLibraries.Clear();
            TextWindow.Hide();
            foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    if (assembly.GetName().Name == "SmallBasicLibrary") ParseAssembly(assembly);
                }
                catch (Exception ex)
                {
                    if (showErrors) MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
                }
            }
            progressBarAPI.Value = 10;

            List<string> filePaths = Directory.GetFiles(textBoxXML.Text).ToList();
            foreach (string file in filePaths)
            {
                if (file.EndsWith(".dll"))
                {
                    try
                    {
                        ParseAssembly(Assembly.LoadFrom(file));
                    }
                    catch (FileLoadException ex) { }
                    catch (Exception ex)
                    {
                        if (showErrors) MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
                    }
                }
                progressBarAPI.Value += (int)(80 / (double)(filePaths.Count));
            }
            progressBarAPI.Value = 90;

            treeView1.Nodes.Clear();
            treeView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            treeView1.ImageList = new System.Windows.Forms.ImageList();
            Assembly execAssembly = Assembly.GetExecutingAssembly();
            treeView1.ImageList.Images.Add(System.Drawing.Image.FromStream(execAssembly.GetManifestResourceStream("LitDevUtilities.Resources.IntellisenseObject.png")));
            treeView1.ImageList.Images.Add(System.Drawing.Image.FromStream(execAssembly.GetManifestResourceStream("LitDevUtilities.Resources.IntellisenseMethod.png")));
            treeView1.ImageList.Images.Add(System.Drawing.Image.FromStream(execAssembly.GetManifestResourceStream("LitDevUtilities.Resources.IntellisenseProperty.png")));
            treeView1.ImageList.Images.Add(System.Drawing.Image.FromStream(execAssembly.GetManifestResourceStream("LitDevUtilities.Resources.IntellisenseEvent.png")));
            treeView1.ImageList.Images.Add(System.Drawing.Image.FromStream(execAssembly.GetManifestResourceStream("LitDevUtilities.Resources.SBIcon.png")));
            SBLibraries.Sort();
            foreach (SBLibrary _SBLibrary in SBLibraries)
            {
                TreeNode[] TNLibrary = new TreeNode[_SBLibrary.SBClasses.Count];
                int i = 0;
                _SBLibrary.SBClasses.Sort();
                foreach (SBClass _SBClass in _SBLibrary.SBClasses)
                {
                    TreeNode[] TNClass = new TreeNode[_SBClass.SBObjects.Count + 1];
                    int j = 0;
                    TNClass[j++] = new TreeNode(_SBClass.summary,100,100);
                    _SBClass.SBObjects.Sort();
                    foreach (SBObject _SBObject in _SBClass.SBObjects)
                    {
                        int iReturn = (null != _SBObject.returns && _SBObject.returns.Length > 0) ? 1 : 0;
                        TreeNode[] TNObject = new TreeNode[1 + iReturn + _SBObject.SBParams.Count + _SBObject.SBParamsAdditional.Count];
                        int k = 0;
                        TNObject[k++] = new TreeNode(_SBObject.summary, 100, 100);
                        foreach (SBParam _SBParam in _SBObject.SBParams)
                        {
                            TreeNode[] TNParam = new TreeNode[1];
                            TNParam[0] = new TreeNode(_SBParam.description, 100, 100);
                            TNObject[k++] = new TreeNode("Parameter - " + _SBParam.name, 100, 100, TNParam);
                        }
                        foreach (SBParam _SBParam in _SBObject.SBParamsAdditional)
                        {
                            TreeNode[] TNParam = new TreeNode[1];
                            TNParam[0] = new TreeNode(_SBParam.description, 100, 100);
                            TNObject[k++] = new TreeNode(_SBParam.name, 100, 100, TNParam);
                        }
                        if (iReturn > 0)
                        {
                            TreeNode[] TNReturn = new TreeNode[1];
                            TNReturn[0] = new TreeNode(_SBObject.returns, 100, 100);
                            TNObject[k++] = new TreeNode("Returns", 100, 100, TNReturn);
                        }
                        switch (_SBObject.etype)
                        {
                            case eType.METHOD:
                                string parameters = "";
                                if (_SBObject.SBParams.Count > 0)
                                {
                                    parameters += "(";
                                    int l = 0;
                                    foreach (SBParam _SBParam in _SBObject.SBParams)
                                    {
                                        parameters += _SBParam.name;
                                        if (++l < _SBObject.SBParams.Count) parameters += ", ";
                                    }
                                    parameters += ")";
                                }
                                TNClass[j++] = new TreeNode(_SBObject.name + parameters, 1, 1, TNObject);
                                break;
                            case eType.PROPERTY:
                                TNClass[j++] = new TreeNode(_SBObject.name, 2, 2, TNObject);
                                break;
                            case eType.EVENT:
                                TNClass[j++] = new TreeNode(_SBObject.name, 3, 3, TNObject);
                                break;
                        }
                    }
                    TNLibrary[i++] = new TreeNode(_SBClass.name, 0, 0, TNClass);
                }
                treeView1.Nodes.Add(new TreeNode(_SBLibrary.name, 4, 4, TNLibrary));
            }
            progressBarAPI.Value = 100;
        }

        private void ParseAssembly(Assembly assembly)
        {
            textBoxAPI.Text = assembly.GetName().Name;
            textBoxAPI.Update();
            List<string> xmlFiles = XMLFromAssembly(assembly);
            StreamReader streamReader;
            string fullName;

            foreach (string xmlFile in xmlFiles)
            {
                streamReader = new StreamReader(xmlFile);
                XmlDocument xmlDocument = new XmlDocument();
                xmlDocument.Load(streamReader);

                SBLibrary _SBLibrary = new SBLibrary();
                _SBLibrary.name = Path.GetFileNameWithoutExtension(xmlFile); ;

                foreach (Type type in assembly.GetExportedTypes())
                {
                    var attribute = type.GetCustomAttributes(typeof(SmallBasicTypeAttribute), false);
                    if (attribute != null && attribute.Length > 0)
                    {
                        SBClass _SBClass = new SBClass();
                        _SBClass.name = type.Name;
                        fullName = "T:" + type.FullName;
                        foreach (XmlElement xmlElement in xmlDocument["doc"]["members"])
                        {
                            if (xmlElement.Attributes["name"].Value.StartsWith(fullName))
                            {
                                foreach (XmlNode node in xmlElement.ChildNodes)
                                {
                                    if (node.Name == "summary") _SBClass.summary = FormatText(node.InnerText);
                                }
                                break;
                            }
                        }

                        foreach (MethodInfo methodInfo in type.GetMethods(BindingFlags.Public | BindingFlags.Static))
                        {
                            attribute = methodInfo.GetCustomAttributes(typeof(HideFromIntellisenseAttribute), false);
                            if (attribute != null && attribute.Length > 0) continue;
                            if (methodInfo.Name.StartsWith("get_") || methodInfo.Name.StartsWith("set_")) continue;
                            if (methodInfo.ReturnType != typeof(Primitive) && methodInfo.ReturnType != typeof(void)) continue;
                            bool parametersOK = true;
                            foreach (ParameterInfo parameterInfo in methodInfo.GetParameters())
                            {
                                if (parameterInfo.ParameterType != typeof(Primitive)) parametersOK = false;
                            }
                            if (!parametersOK) continue;

                            SBObject _SBObject = new SBObject(eType.METHOD);
                            _SBObject.name = methodInfo.Name;

                            fullName = "M:" + methodInfo.DeclaringType.FullName + "." + methodInfo.Name;
                            SetSBObject(xmlDocument, _SBObject, fullName);

                            _SBClass.SBObjects.Add(_SBObject);
                        }

                        foreach (PropertyInfo propertyInfo in type.GetProperties(BindingFlags.Public | BindingFlags.Static))
                        {
                            attribute = propertyInfo.GetCustomAttributes(typeof(HideFromIntellisenseAttribute), false);
                            if (attribute != null && attribute.Length > 0) continue;
                            if (propertyInfo.PropertyType != typeof(Primitive)) continue;

                            SBObject _SBObject = new SBObject(eType.PROPERTY);
                            _SBObject.name = propertyInfo.Name;

                            fullName = "P:" + propertyInfo.DeclaringType.FullName + "." + propertyInfo.Name;
                            SetSBObject(xmlDocument, _SBObject, fullName);

                            _SBClass.SBObjects.Add(_SBObject);
                        }

                        foreach (EventInfo eventInfo in type.GetEvents(BindingFlags.Public | BindingFlags.Static))
                        {
                            attribute = eventInfo.GetCustomAttributes(typeof(HideFromIntellisenseAttribute), false);
                            if (attribute != null && attribute.Length > 0) continue;
                            if (eventInfo.EventHandlerType != typeof(SmallBasicCallback)) continue;

                            SBObject _SBObject = new SBObject(eType.EVENT);
                            _SBObject.name = eventInfo.Name;

                            fullName = "E:" + eventInfo.DeclaringType.FullName + "." + eventInfo.Name;
                            SetSBObject(xmlDocument, _SBObject, fullName);

                            _SBClass.SBObjects.Add(_SBObject);
                        }

                        _SBLibrary.SBClasses.Add(_SBClass);
                    }
                }
                if (_SBLibrary.SBClasses.Count > 0) SBLibraries.Add(_SBLibrary);
                textBoxAPI.Text = "";
            }
        }

        private string FormatText(string text)
        {
            text = text.Trim();
            while (text.Contains("  ")) text = text.Replace("  ", " ");
            return text;
        }

        private void SetSBObject(XmlDocument xmlDocument, SBObject _SBObject, string fullName)
        {
            foreach (XmlElement xmlElement in xmlDocument["doc"]["members"])
            {
                if (xmlElement.Attributes["name"].Value.StartsWith(fullName))
                {
                    foreach (XmlNode node in xmlElement.ChildNodes)
                    {
                        try
                        {
                            if (node.Name == "summary") _SBObject.summary = FormatText(node.InnerText);
                            else if (node.Name == "returns") _SBObject.returns = FormatText(node.InnerText);
                            else if (node.Name == "param")
                            {
                                XmlAttribute attrib = node.Attributes["name"];
                                if (null != attrib) _SBObject.SBParams.Add(new SBParam(attrib.Value, FormatText(node.InnerText)));
                            }
                            else if (null != node.Attributes)
                            {
                                XmlAttribute attrib = node.Attributes["name"];
                                if (null != attrib) _SBObject.SBParamsAdditional.Add(new SBParam(node.Name, FormatText(node.InnerText)));
                            }
                        }
                        catch (Exception ex)
                        {
                            if (showErrors) MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
                        }
                    }
                    break;
                }
            }
       }

        private List<string> XMLFromAssembly(Assembly assembly)
        {
            string assemblyFilename = assembly.CodeBase;
            List<string> xmlFiles = new List<string>();

            const string prefix = "file:///";

            if (assemblyFilename.StartsWith(prefix))
            {
                try
                {
                    string filePath = assemblyFilename.Substring(prefix.Length);
                    string folderName = Path.GetDirectoryName(filePath);
                    string fileName = Path.GetFileNameWithoutExtension(filePath);
                    string[] files = Directory.GetFiles(folderName);
                    if (fileName == "SmallBasicLibrary" && files.Length == 0)
                    {
                        files = Directory.GetFiles(textBoxXML.Text);
                    }
                    foreach (string file in files)
                    {
                        string fileRoot = Path.GetFileNameWithoutExtension(file);
                        int pos = fileRoot.IndexOf('.');
                        if (pos > 0) fileRoot = fileRoot.Substring(0, pos);
                        if (fileRoot == fileName && Path.GetExtension(file).ToLower() == ".xml")
                        {
                            xmlFiles.Add(file);
                        }
                    }
                }
                catch (Exception ex)
                {
                    if (showErrors) MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK);
                }
            }
            return xmlFiles;
        }
        
        private void ResetColours()
        {
            foreach (TreeNode node1 in treeView1.Nodes)
            {
                node1.ForeColor = System.Drawing.SystemColors.ControlText;
                foreach (TreeNode node2 in node1.Nodes)
                {
                    node2.ForeColor = System.Drawing.SystemColors.ControlText;
                    foreach (TreeNode node3 in node2.Nodes)
                    {
                        node3.ForeColor = System.Drawing.SystemColors.ControlText;
                        foreach (TreeNode node4 in node3.Nodes)
                        {
                            node4.ForeColor = System.Drawing.SystemColors.ControlText;
                            foreach (TreeNode node5 in node4.Nodes)
                            {
                                node5.ForeColor = System.Drawing.SystemColors.ControlText;
                            }
                        }
                    }
                }
            }
        }

        private void Search()
        {
            ResetColours();
            treeView1.CollapseAll();
            string text = textBoxSearch.Text.ToLower();
            if (text.Length < 1) return;
            if (treeView1.Nodes.Count == 0) return;
            foreach (TreeNode node1 in treeView1.Nodes)
            {
                if (node1.Text.ToLower().Contains(text)) node1.EnsureVisible();
                else node1.ForeColor = System.Drawing.SystemColors.ActiveBorder;
                foreach (TreeNode node2 in node1.Nodes)
                {
                    if (node2.Text.ToLower().Contains(text)) node2.EnsureVisible();
                    else node2.ForeColor = System.Drawing.SystemColors.ActiveBorder;
                    foreach (TreeNode node3 in node2.Nodes)
                    {
                        if (node3.Text.ToLower().Contains(text)) node3.EnsureVisible();
                        else node3.ForeColor = System.Drawing.SystemColors.ActiveBorder;
                        foreach (TreeNode node4 in node3.Nodes)
                        {
                            if (node4.Text.ToLower().Contains(text)) node4.EnsureVisible();
                            else node4.ForeColor = System.Drawing.SystemColors.ActiveBorder;
                            foreach (TreeNode node5 in node4.Nodes)
                            {
                                if (node5.Text.ToLower().Contains(text)) node5.EnsureVisible();
                                else node5.ForeColor = System.Drawing.SystemColors.ActiveBorder;
                            }
                        }
                    }
                }
            }
            treeView1.Nodes[0].EnsureVisible();
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            treeView1.BeginUpdate();
            Search();
            treeView1.EndUpdate();
        }

        private void buttonCollapseAll_Click(object sender, EventArgs e)
        {
            treeView1.BeginUpdate();
            ResetColours();
            treeView1.CollapseAll();
            treeView1.EndUpdate();
        }

        private void buttonExpand_Click(object sender, EventArgs e)
        {
            treeView1.BeginUpdate();
            ResetColours();
            if (null == treeView1.SelectedNode)
            {
                treeView1.ExpandAll();
                if (treeView1.Nodes.Count > 0) treeView1.Nodes[0].EnsureVisible();
            }
            else
            {
                treeView1.SelectedNode.ExpandAll();
                treeView1.SelectedNode.EnsureVisible();
            }
            treeView1.EndUpdate();
        }

        private void buttonLoad_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            InitialiseLibraries();
            Cursor.Current = Cursors.Default;
        }

        #endregion
    }

    class ListViewColumnSorter : IComparer
    {
        /// <summary>
        /// Specifies the column to be sorted
        /// </summary>
        private int ColumnToSort;

        /// <summary>
        /// Specifies the order in which to sort (i.e. 'Ascending').
        /// </summary>
        private SortOrder OrderOfSort;

        /// <summary>
        /// Case insensitive comparer object
        /// </summary>
        private CaseInsensitiveComparer ObjectCompare;

        /// <summary>
        /// Class constructor.  Initializes various elements
        /// </summary>
        public ListViewColumnSorter()
        {
            // Initialize the column to '0'
            ColumnToSort = 0;

            // Initialize the sort order to 'none'
            OrderOfSort = SortOrder.None;

            // Initialize the CaseInsensitiveComparer object
            ObjectCompare = new CaseInsensitiveComparer();
        }

        /// <summary>
        /// This method is inherited from the IComparer interface.  It compares the two objects passed using a case insensitive comparison.
        /// </summary>
        /// <param name="x">First object to be compared</param>
        /// <param name="y">Second object to be compared</param>
        /// <returns>The result of the comparison. "0" if equal, negative if 'x' is less than 'y' and positive if 'x' is greater than 'y'</returns>
        public int Compare(object x, object y)
        {
            int compareResult;
            ListViewItem listviewX, listviewY;

            // Cast the objects to be compared to ListViewItem objects
            listviewX = (ListViewItem)x;
            listviewY = (ListViewItem)y;

            // Compare the two items
            compareResult = ObjectCompare.Compare(listviewX.SubItems[ColumnToSort].Tag, listviewY.SubItems[ColumnToSort].Tag);

            // Calculate correct return value based on object comparison
            if (OrderOfSort == SortOrder.Ascending)
            {
                // Ascending sort is selected, return normal result of compare operation
                return compareResult;
            }
            else if (OrderOfSort == SortOrder.Descending)
            {
                // Descending sort is selected, return negative result of compare operation
                return (-compareResult);
            }
            else
            {
                // Return '0' to indicate they are equal
                return 0;
            }
        }

        /// <summary>
        /// Gets or sets the number of the column to which to apply the sorting operation (Defaults to '0').
        /// </summary>
        public int SortColumn
        {
            set
            {
                ColumnToSort = value;
            }
            get
            {
                return ColumnToSort;
            }
        }

        /// <summary>
        /// Gets or sets the order of sorting to apply (for example, 'Ascending' or 'Descending').
        /// </summary>
        public SortOrder Order
        {
            set
            {
                OrderOfSort = value;
            }
            get
            {
                return OrderOfSort;
            }
        }
    }

    enum eType { METHOD, PROPERTY, EVENT }

    class SBParam
    {
        public string name { get; set; }
        public string description { get; set; }

        public SBParam(string name, string description)
        {
            this.name = name;
            this.description = description;
        }
    }

    class SBObject : IComparable
    {
        public eType etype { get; set; }
        public string name { get; set; }
        public List<SBParam> SBParams { get; set; }
        public List<SBParam> SBParamsAdditional { get; set; }
        public string summary { get; set; }
        public string returns { get; set; }

        public SBObject(eType etype)
        {
            this.etype = etype;
            SBParams = new List<SBParam>();
            SBParamsAdditional = new List<SBParam>();
        }

        int IComparable.CompareTo(object obj)
        {
            if (etype == ((SBObject)obj).etype)
            {
                return name.CompareTo(((SBObject)obj).name);
            }
            else
            {
                return etype.CompareTo(((SBObject)obj).etype);
            }
        }
    }

    class SBClass : IComparable
    {
        public string name { get; set; }
        public string summary { get; set; }
        public List<SBObject> SBObjects { get; set; }

        public SBClass()
        {
            SBObjects = new List<SBObject>();
        }

        int IComparable.CompareTo(object obj)
        {
            return name.CompareTo(((SBClass)obj).name);
        }
    }

    class SBLibrary : IComparable
    {
        public string name { get; set; }
        public List<SBClass> SBClasses { get; set; }

        public SBLibrary()
        {
            SBClasses = new List<SBClass>();
        }

        int IComparable.CompareTo(object obj)
        {
            return name.CompareTo(((SBLibrary)obj).name);
        }
    }
}

