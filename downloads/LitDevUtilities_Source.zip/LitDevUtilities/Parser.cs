﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.IO;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace LitDevUtilities
{
    enum attribute
    {
        None, Type, Method, Property, Event
    }

    class Group : IComparable
    {
        public Member member;
        public List<Member> members;

        public Group()
        {
            members = new List<Member>();
        }

        int IComparable.CompareTo(object obj)
        {
            return member.header.text.CompareTo(((Group)obj).member.header.text);
        }
    }

    class Member : IComparable
    {
        public Header header;
        public List<Node> nodes;

        public Member()
        {
            nodes = new List<Node>();
        }

        int IComparable.CompareTo(object obj)
        {
            if (null == header.text || null == obj) return 0;
            return header.text.CompareTo(((Member)obj).header.text);
        }
    }

    class Node
    {
        public string type;
        public string name;
        public string value;

        public Node()
        {
            type = "";
            name = null;
            value = "";
        }
    }

    class Header
    {
        public attribute attrib;
        public string text;
    }

    class RTFconstants
    {
        public string Title;
        public string Command;
        public string SubCommand;
        public string Desc;
        public string Text;
        public string Code;
        public string Member;
        public string Param;
        public string Event;
        public string Keyword;
        public string End;

        public RTFconstants(int size)
        {
            switch (size)
            {
                case 0:
                    Title = "\\f0\\pard\\qc{\\fs60\\b ";
                    Command = "\\f0\\pard\\sb400\\shading2000{\\fs48\\b ";
                    SubCommand = "\\f0\\pard\\sb240\\shading1000{\\fs36\\b ";
                    Desc = "\\f0\\pard\\sb100{\\fs28\\b ";
                    Text = "\\f0\\pard{\\fs24 ";
                    Code = "\\f0\\pard{\\fs22\\i ";
                    Member = " \\fs20\\b0\\i OPERATION";
                    Param = " \\fs20\\b0\\i PARAMETER";
                    Event = " \\fs20\\b0\\i EVENT";
                    Keyword = " \\fs20\\b0\\i KEYWORD";
                    End = "}\\par";
                    break;
                case 1:
		            Title = "\\f0\\pard\\qc{\\fs45\\b ";
		            Command = "\\f0\\pard\\sb300\\shading2000{\\fs36\\b ";
		            SubCommand = "\\f0\\pard\\sb180\\shading1000{\\fs30\\b ";
		            Desc = "\\f0\\pard\\sb75{\\fs24\\b ";
		            Text = "\\f0\\pard{\\fs20 ";
		            Code = "\\f0\\pard{\\fs18\\i ";
		            Member = " \\fs18\\b0\\i OPERATION";
		            Param = " \\fs18\\b0\\i PARAMETER";
		            Event = " \\fs18\\b0\\i EVENT";
		            Keyword = " \\fs18\\b0\\i KEYWORD";
		            End = "}\\par";
                    break;
                case 2:
		            Title = "\\f0\\pard\\qc{\\fs30\\b ";
		            Command = "\\f0\\pard\\sb250\\shading2000{\\fs28\\b ";
		            SubCommand = "\\f0\\pard\\sb240\\shading1000{\\fs24\\b ";
		            Desc = "\\f0\\pard\\sb60{\\fs20\\b ";
		            Text = "\\f0\\pard{\\fs18 ";
		            Code = "\\f0\\pard{\\fs16\\i ";
		            Member = " \\fs16\\b0\\i OPERATION";
		            Param = " \\fs16\\b0\\i PARAMETER";
		            Event = " \\fs16\\b0\\i EVENT";
		            Keyword = " \\fs16\\b0\\i KEYWORD";
		            End = "}\\par";
                    break;
                case 3:
		            Title = "\\f0\\pard\\qc{\\fs24\\b ";
		            Command = "\\f0\\pard\\sb200\\shading2000{\\fs20\\b ";
		            SubCommand = "\\f0\\pard\\sb125\\shading1000{\\fs18\\b ";
		            Desc = "\\f0\\pard\\sb50{\\fs16\\b ";
		            Text = "\\f0\\pard{\\fs14 ";
		            Code = "\\f0\\pard{\\fs12\\i ";
		            Member = " \\fs12\\b0\\i OPERATION";
		            Param = " \\fs12\\b0\\i PARAMETER";
		            Event = " \\fs12\\b0\\i EVENT";
		            Keyword = " \\fs12\\b0\\i KEYWORD";
		            End = "}\\par";
                    break;
            }
        }
    }

    class Parser
    {
        string xmlFile;
        List<string> exclude;
        string extName;
        XmlTextReader reader;
        string assembly;
        List<Group> groups;
        Group group;
        Member member;
        Node node;
        bool bMyUser = false;

        public StreamWriter getStreamWriter(string fileName, Encoding encoding)
        {
            try
            {
                return new StreamWriter(fileName, false, encoding);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error", MessageBoxButtons.OK);
            }
            return null;
        }

        public Parser(string _xmlFile, List<string> _exclude, string _extName)
        {
            xmlFile = _xmlFile;
            exclude = _exclude;
            extName = _extName.Split('.')[0];
            try
            {
                reader = new XmlTextReader(xmlFile);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "Error", MessageBoxButtons.OK);
                reader = null;
            }
            groups = null;
        }

        public List<Group> Parse()
        {
            if (null == reader) return null;
            while (reader.Read())
            {
                switch (reader.NodeType)
                {
                    case XmlNodeType.Element:
                        {
                            if (reader.Name == "assembly")
                            {
                                groups = new List<Group>();
                                assembly = "";
                            }
                            else if (reader.Name == "member" && reader.HasAttributes)
                            {
                                if (null == groups) continue;
                                for (int i = 0; i < reader.AttributeCount; i++)
                                {
                                    reader.MoveToAttribute(i);
                                    if (reader.Name == "name")
                                    {
                                        member = new Member();
                                        member.header = getHeader(reader.Value);
                                        if (member.header.attrib == attribute.Type)
                                        {
                                            group = new Group();
                                            group.member = member;
                                            groups.Add(group);
                                        }
                                        else if (member.header.attrib == attribute.None)
                                        {
                                            group = null;
                                        }
                                        else if (null != group)
                                        {
                                            group.members.Add(member);
                                        }
                                    }
                                }
                            }
                            else
                            {
                                if (null == member) continue;
                                node = new Node();
                                node.type = reader.Name;
                                for (int i = 0; i < reader.AttributeCount; i++)
                                {
                                    reader.MoveToAttribute(i);
                                    if (reader.Name == "name")
                                    {
                                        node.name = reader.Value;
                                    }
                                }
                                member.nodes.Add(node);
                            }
                        }
                        break;
                    case XmlNodeType.Text:
                        if (assembly == "") assembly = reader.Value;
                        if (null == node) continue;
                        node.value = reader.Value;
                        node.value = node.value.Replace("\r\n            ", "\r\n");
                        node.value = node.value.Trim(new char[] {'\r', '\n'});
                        break;
                    case XmlNodeType.EndElement:
                        break;
                }
            }

            if (null == groups) return groups;
            groups.Sort();
            for (int i = groups.Count - 1; i >= 0; i--)
            {
                Group group1 = groups[i];
                //Default exclusions
                foreach (string ex in exclude)
                {
                    if (group1.member.header.text.ToLower() == ex.ToLower()) groups.Remove(group1);
                }
            }
            return groups;
        }

        private void writeHeader(StreamWriter sw, bool bSeparateFiles, string caseName)
        {
            //sw.WriteLine("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">"); 
            sw.WriteLine("<!DOCTYPE html>");
            sw.WriteLine("<html xmlns=\"http://www.w3.org/1999/xhtml\">");
            sw.WriteLine("<head>");
            sw.WriteLine(" <meta http-equiv=\"Content-type\" content=\"text/html;charset=UTF-8\">");
            sw.WriteLine(" <title>" + assembly + " API</title>");
            sw.WriteLine(" <meta name=\"description\" content=\"SmallBasic " + assembly + " extension API\" />");
            sw.WriteLine(" <meta name=\"keywords\" content=\"SmallBasic,litdev," + assembly + "extension\" />");
            sw.WriteLine(" <link rel=\"stylesheet\" type=\"text/css\" href=\"styleAPI.css\" />");
            sw.WriteLine(" <link rel=\"shortcut icon\" href=\"favicon.ico\" />");
            sw.WriteLine("</head>");
            sw.WriteLine("<body>");
            sw.WriteLine("<div id=\"wrapper\">");
            sw.WriteLine("<div id=\"content\">");
            sw.WriteLine();
            writeLine(sw, assembly, "", "assembly");
            if (bMyUser)
            {
                sw.WriteLine("<form action=\"sphider/search.php\" method=\"get\" >");
                sw.WriteLine(" <div style=\"text-align: center\" >");
                sw.WriteLine("  <input type=\"text\" name=\"query\" id=\"query\" size=\"40\" action=\"sphider/include/js_suggest/suggest.php\" columns=\"2\" autocomplete=\"off\" delay=\"1500\" />");
                sw.WriteLine("  <input type=\"hidden\" value=\"and\" name=\"type\" />");
                sw.WriteLine("  <input type=\"hidden\" value=\"50\" name=\"results\" />");
                sw.WriteLine("  <input type=\"hidden\" value=\"1\" name=\"search\" />");
                sw.WriteLine("  <input type=\"submit\" value=\" Search \" />");
                sw.WriteLine(" </div>");
                sw.WriteLine("</form>");
                sw.WriteLine("<p class=\"links\">");
                sw.WriteLine("&nbsp;<a href=\"index.html\">Return to Main Page</a><br />");
                sw.WriteLine("</p>");
            }
            sw.WriteLine("<table class=\"table\" cellpadding=\"4\">");
            int i = 0;
            foreach (Group group in groups)
            {
                string text = group.member.header.text;
                if (i % 5 == 0) sw.WriteLine("<tr>");
                sw.WriteLine("<td>");
                string file = bSeparateFiles ? caseName + "_" + text + ".html" : "#" + text;
                sw.WriteLine("<a href=\"" + file + "\">" + text + "</a>");
                sw.WriteLine("</td>");
                i++;
                if (i % 5 == 0) sw.WriteLine("</tr>");
            }
            if (i % 5 != 0) sw.WriteLine("</tr>");
            sw.WriteLine("</table>");
        }

        private void writeFooter(StreamWriter sw)
        {
            sw.WriteLine("<br />");
            if (bMyUser)
            {
                sw.WriteLine("<div id=\"footer\">");
                sw.WriteLine("<hr style=\"height: 2px; width: 100%;\" />");
                sw.WriteLine("<a style=\"position: relative; float: left;\" href=\"http://free-website-translation.com/\" id=\"ftwtranslation_button\" hreflang=\"en\" title=\"\" style=\"border:0;\"><img src=\"http://free-website-translation.com/img/fwt_button_en.gif\" id=\"ftwtranslation_image\" alt=\"Website Translation Widget\" style=\"border:0;\"/></a> <script type=\"text/javascript\" src=\"http://free-website-translation.com/scripts/fwt.js\" /></script>");
                //sw.WriteLine("<a style=\"position: relative; float: right;\" href=\"http://www.000webhost.com/\" target=\"_blank\"><img src=\"http://www.000webhost.com/images/80x15_powered.gif\" alt=\"Web Hosting\" width=\"80\" height=\"15\" border=\"0\" /></a>");
                sw.WriteLine("</div>");
            }
            sw.WriteLine("</div>");
            sw.WriteLine("</div>");
            sw.WriteLine("</body>");
            if (bMyUser)
            {
                writeAnalytics(sw);
            }
            sw.WriteLine("</html>");
        }

        private void writeAnalytics(StreamWriter sw)
        {
            sw.WriteLine("<script>");

            sw.WriteLine("(function (i, s, o, g, r, a, m) {");
                sw.WriteLine(" i['GoogleAnalyticsObject'] = r; i[r] = i[r] || function () {");
                    sw.WriteLine("  (i[r].q = i[r].q || []).push(arguments)");
                sw.WriteLine(" }, i[r].l = 1 * new Date(); a = s.createElement(o),");
                sw.WriteLine(" m = s.getElementsByTagName(o)[0]; a.async = 1; a.src = g; m.parentNode.insertBefore(a, m)");
            sw.WriteLine("})(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');");

            sw.WriteLine("ga('create', 'UA-28519634-1', 'auto');");
            sw.WriteLine("ga('send', 'pageview');");

            sw.WriteLine("</script>");

            //sw.WriteLine("<script type=\"text/javascript\">");

            //sw.WriteLine("var _gaq = _gaq || [];");
            //sw.WriteLine("_gaq.push(['_setAccount', 'UA-28519634-1']);");
            //sw.WriteLine("_gaq.push(['_trackPageview']);");

            //sw.WriteLine("(function () {");
            //sw.WriteLine("var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;");
            ////sw.WriteLine("ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';");
            //sw.WriteLine("ga.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'stats.g.doubleclick.net/dc.js';");
            //sw.WriteLine("var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);");
            //sw.WriteLine("})();");

            //sw.WriteLine("</script>");
        }

        private void writeLine(StreamWriter sw, string text, string link, string style, attribute attrib = attribute.None)
        {
            if (null == text) return;
            if (style == "text" && text == "") return;
            text = text.Trim();
            text = text.Replace("\r\n", "<br />");

            Regex urlRx = new Regex("http://([\\w+?\\.\\w+])+([a-zA-Z0-9\\~\\!\\@\\#\\$\\%\\^\\&amp;\\*_\\-\\=\\+\\\\\\/\\?\\.\\:\\;\\'\\,]*)?", RegexOptions.IgnoreCase);
            MatchCollection matches = urlRx.Matches(text); 
            foreach (Match match in matches)
            {
                text = text.Replace(match.Value, "<a href=\"" + match.Value + "\">" + match.Value + "</a>"); 
            }

            if (style == "assembly" && text != "SmallBasicLibrary") text += " Extension";
            if (style == "assembly") text += " API";
            if (style == "group" || style == "method") sw.WriteLine("<br />");
            if (link != "")
            {
                sw.Write("<a class=\"tag\" name=\"" + link + "\"></a>");
            }
            if (style == "assembly")
            {
                sw.Write("<p class=\"" + style + "\">");
                sw.Write(text);
                sw.Write("</p>");
            }
            else
            {
                sw.Write("<span class=\"" + style + "\">");
                sw.Write(text);
                sw.Write("</span>");
            }
            if (attrib == attribute.Method) sw.WriteLine(" <img alt=\"\" height=\"20px\" src=\"images/IntellisenseMethod.png\" />");
            else if (attrib == attribute.Property) sw.WriteLine(" <img alt=\"\" height=\"20px\" src=\"images/IntellisenseProperty.png\" />");
            else if (attrib == attribute.Event) sw.WriteLine(" <img alt=\"\" height=\"20px\" src=\"images/IntellisenseEvent.png\" />");
            else if (style == "group") sw.WriteLine(" <img alt=\"\" height=\"24px\" src=\"images/IntellisenseObject.png\" />");
            if (style == "info")
            {
                sw.Write(" ");
            }
            else if (style == "assembly")
            {
                sw.WriteLine();
            }
            else if (style != "method")
            {
                sw.WriteLine("<br />");
            }
        }

        public void writeHTML(string htmlFile, bool _bMyUser, bool bSeparateFiles)
        {
            string path = Path.GetDirectoryName(htmlFile);
            string caseName = Path.GetFileNameWithoutExtension(htmlFile);
            bMyUser = _bMyUser;
            int nFiles = bSeparateFiles ? groups.Count : 1;
            for (int iFile = bSeparateFiles ? -1 : 0; iFile < nFiles; iFile++)
            {
                string file = bSeparateFiles && iFile >= 0 ? caseName + "_" + groups[iFile].member.header.text : caseName;
                StreamWriter sw = getStreamWriter(path + "\\" + file + ".html", Encoding.UTF8);
                if (null == sw) return;
                writeHeader(sw, bSeparateFiles, caseName);
                string args;
                for (int jFile = 0; jFile < groups.Count; jFile++)
                {
                    if (bSeparateFiles && (iFile != jFile)) continue;
                    Group group = groups[jFile];
                    Member member1 = group.member;
                    writeLine(sw, member1.header.text, member1.header.text, "group");
                    foreach (Node node1 in member1.nodes)
                    {
                        if (!node1.type.ToLower().Contains("summary")) writeLine(sw, node1.type, "", "info");
                        writeLine(sw, node1.value, "", "text");
                    }
                    group.members.Sort();
                    sw.WriteLine("<br />");
                    sw.WriteLine("<table class=\"table\"  cellpadding=\"4\">");
                    int i = 0;
                    foreach (Member member2 in group.members)
                    {
                        string text = member2.header.text;
                        if (i % 3 == 0) sw.WriteLine("<tr>");
                        sw.WriteLine("<td>");
                        sw.WriteLine("<a href=\"#" + member1.header.text + text + "\">" + text + "</a>");
                        if (member2.header.attrib == attribute.Method) sw.WriteLine(" <img alt=\"\" height=\"20px\" src=\"images/IntellisenseMethod.png\" />");
                        else if (member2.header.attrib == attribute.Property) sw.WriteLine(" <img alt=\"\" height=\"20px\" src=\"images/IntellisenseProperty.png\" />");
                        else if (member2.header.attrib == attribute.Event) sw.WriteLine(" <img alt=\"\" height=\"20px\" src=\"images/IntellisenseEvent.png\" />");
                        sw.WriteLine("</td>");
                        i++;
                        if (i % 3 == 0) sw.WriteLine("</tr>");
                    }
                    if (i % 3 != 0) sw.WriteLine("</tr>");
                    sw.WriteLine("</table>");
                    foreach (Member member2 in group.members)
                    {
                        args = "";
                        if (member2.header.attrib == attribute.Method)
                        {
                            args = "(";
                            foreach (Node node2 in member2.nodes)
                            {
                                if (null != node2.name)
                                {
                                    args += node2.name + ",";
                                }
                            }
                            if (args.EndsWith(",")) args = args.Substring(0, args.Length - 1);
                            args += ")";
                        }
                        if (member2.header.text == "Dispose") continue;
                        if (member2.header.text == "InitializeComponent") continue;
                        writeLine(sw, member2.header.text, member1.header.text + member2.header.text, "method");
                        writeLine(sw, args, "", "methodargs", member2.header.attrib);
                        foreach (Node node3 in member2.nodes)
                        {
                            if (null == node3.name)
                            {
                                if (!node3.type.ToLower().Contains("summary")) writeLine(sw, node3.type, "", "info");
                            }
                            else
                            {
                                writeLine(sw, node3.name, "", "info");
                            }
                            writeLine(sw, node3.value, "", "text");
                        }
                    }
                }
                writeFooter(sw);
                sw.Close();
            }
        }

        public void writeRTF(string rtfFile, int size)
        {
            RTFconstants rtf = new RTFconstants(size);
            StreamWriter sw = getStreamWriter(rtfFile, Encoding.ASCII);
            if (null == sw) return;

            sw.WriteLine("{\\rtf1\\ansi");
            sw.WriteLine("{\\fonttbl\\f0\\fswiss Helvetica;}");
            sw.WriteLine("");
            if (assembly == "SmallBasicLibrary")
            {
                sw.WriteLine(rtf.Title + assembly + " API" + rtf.End);
            }
            else
            {
                sw.WriteLine(rtf.Title + assembly + " Extension API" + rtf.End);
            }
            sw.WriteLine("");

            string args;
            foreach (Group group in groups)
            {
                Member member1 = group.member;
                sw.WriteLine(rtf.Command + member1.header.text + rtf.End);
                foreach (Node node1 in member1.nodes)
                {
                    if (!node1.type.ToLower().Contains("summary")) sw.WriteLine(rtf.Desc + node1.type + rtf.End);
                    string text = node1.value.Replace("\\", "\\\\");
                    text = text.Replace("\r\n", "{\\line}");
                    sw.WriteLine(rtf.Text + text + rtf.End);
                }
                group.members.Sort();
                sw.WriteLine("");
                foreach (Member member2 in group.members)
                {
                    args = "";
                    if (member2.header.attrib == attribute.Method)
                    {
                        args = "(";
                        foreach (Node node2 in member2.nodes)
                        {
                            if (null != node2.name)
                            {
                                args += node2.name + ",";
                            }
                        }
                        if (args.EndsWith(",")) args = args.Substring(0, args.Length - 1);
                        args += ")";
                    }
                    if (member2.header.text == "Dispose") continue;
                    if (member2.header.text == "InitializeComponent") continue;
                    sw.WriteLine(rtf.SubCommand + member2.header.text + args + rtf.Member + rtf.End);
                    foreach (Node node3 in member2.nodes)
                    {
                        if (null == node3.name)
                        {
                            if (!node3.type.ToLower().Contains("summary")) sw.WriteLine(rtf.Desc + node3.type + rtf.End);
                        }
                        else
                        {
                            sw.WriteLine(rtf.Desc + node3.name + rtf.End);
                        }
                        string text = node3.value.Replace("\\", "\\\\");
                        text = text.Replace("\r\n", "{\\line}");
                        sw.WriteLine(rtf.Text + text + rtf.End);
                    }
                }
            }
            sw.WriteLine("}");
            sw.Close();
        }

        private Header getHeader(string txt)
        {
            Header header = new Header();
            if (txt.StartsWith("T:")) header.attrib = attribute.Type;
            else if (txt.StartsWith("M:")) header.attrib = attribute.Method;
            else if (txt.StartsWith("P:")) header.attrib = attribute.Property;
            else if (txt.StartsWith("E:")) header.attrib = attribute.Event;
            else header.attrib = attribute.None;

            if (!txt.Contains(extName) && extName != "SmallBasicLibrary") header.attrib = attribute.None;

            if (header.attrib != attribute.None)
            {
                if (txt.IndexOf("(") > 0) txt = txt.Substring(0, txt.IndexOf("("));
                header.text = txt.Split('.').Last();
            }
            return header;
        }
    }
}
