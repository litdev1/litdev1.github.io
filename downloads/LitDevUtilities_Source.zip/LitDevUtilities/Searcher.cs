﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace LitDevUtilities
{
    class SBfile : IComparable
    {
        public string file;
        public string folder;
        public string fileName;
        public IEnumerable<string> text;
        public int length;
        public DateTime date;

        public SBfile(string _file)
        {
            file = _file;
            folder = Path.GetDirectoryName(file);
            fileName = Path.GetFileNameWithoutExtension(file);
            text = File.ReadLines(file);
            length = text.Count();
            date = File.GetLastWriteTime(file);
        }

        public int CompareTo(Object obj)
        {
            return file.CompareTo(((SBfile)obj).file);
        }
    }

    class Searcher
    {
        public string root;
        public List<SBfile> SBfiles;

        public Searcher(string _root)
        {
            root = _root;
            SBfiles = new List<SBfile>();
            search();
        }

        private void search()
        {
            if (!Directory.Exists(root)) return;
            Stack<string> dirs = new Stack<string>();
            List<string> files = new List<string>();
            dirs.Push(root);

            int i = 0;
            while (dirs.Count > 0)
            {
                string dir = dirs.Pop();
                string[] _dirs = Directory.GetDirectories(dir);
                foreach (string _dir in _dirs)
                {
                    dirs.Push(_dir);
                }
                string[] _files = Directory.GetFiles(dir);
                foreach (string _file in _files)
                {
                    if (_file.EndsWith(".sb") || _file.EndsWith(".smallbasic")) files.Add(_file);
                }
                Form1.progressBarSearcherValue = Math.Min(75, ++i);
            }
            Form1.progressBarSearcherValue = 75;
            i = 0;
            foreach (string file in files)
            {
                SBfiles.Add(new SBfile(file));
                Form1.progressBarSearcherValue = 75 + (int)(20 * (++i) / (double)files.Count);
            }
            SBfiles.Sort();
        }
    }
}
