﻿namespace LitDevUtilities
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.buttonConvert = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxXML = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxHTML = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBoxCases = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.checkedListBoxExclude = new System.Windows.Forms.CheckedListBox();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.buttonBrowseXML = new System.Windows.Forms.Button();
            this.buttonBrowseHTML = new System.Windows.Forms.Button();
            this.buttonHelpXML = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.checkBoxCSS = new System.Windows.Forms.CheckBox();
            this.checkBoxRTF = new System.Windows.Forms.CheckBox();
            this.comboBoxRTF = new System.Windows.Forms.ComboBox();
            this.checkBoxHTML = new System.Windows.Forms.CheckBox();
            this.checkBoxImages = new System.Windows.Forms.CheckBox();
            this.buttonBrowseRTF = new System.Windows.Forms.Button();
            this.textBoxRTF = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.checkBoxSeparateFiles = new System.Windows.Forms.CheckBox();
            this.progressBarXML = new System.Windows.Forms.ProgressBar();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.buttonCompile = new System.Windows.Forms.Button();
            this.richTextBoxPreview = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxRoot = new System.Windows.Forms.TextBox();
            this.buttonOpen = new System.Windows.Forms.Button();
            this.buttonRoot = new System.Windows.Forms.Button();
            this.textBoxKeyWordCount = new System.Windows.Forms.TextBox();
            this.progressBarSearcher = new System.Windows.Forms.ProgressBar();
            this.checkBoxCase = new System.Windows.Forms.CheckBox();
            this.hScrollBar1 = new System.Windows.Forms.HScrollBar();
            this.buttonCopy = new System.Windows.Forms.Button();
            this.checkBoxWholeWord = new System.Windows.Forms.CheckBox();
            this.listViewSearcher = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.textBoxFileCount = new System.Windows.Forms.TextBox();
            this.textBoxKeyword = new System.Windows.Forms.TextBox();
            this.buttonFilter = new System.Windows.Forms.Button();
            this.buttonRun = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.buttonCurriculum = new System.Windows.Forms.Button();
            this.buttonRefresh = new System.Windows.Forms.Button();
            this.hScrollBar2 = new System.Windows.Forms.HScrollBar();
            this.buttonExtensions = new System.Windows.Forms.Button();
            this.buttonHome = new System.Windows.Forms.Button();
            this.buttonBlog = new System.Windows.Forms.Button();
            this.buttonWiki = new System.Windows.Forms.Button();
            this.buttonForum = new System.Windows.Forms.Button();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.textBoxAPI = new System.Windows.Forms.TextBox();
            this.progressBarAPI = new System.Windows.Forms.ProgressBar();
            this.buttonLoad = new System.Windows.Forms.Button();
            this.buttonExpand = new System.Windows.Forms.Button();
            this.buttonCollapseAll = new System.Windows.Forms.Button();
            this.buttonSearch = new System.Windows.Forms.Button();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonConvert
            // 
            this.buttonConvert.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonConvert.Location = new System.Drawing.Point(15, 585);
            this.buttonConvert.Margin = new System.Windows.Forms.Padding(4);
            this.buttonConvert.Name = "buttonConvert";
            this.buttonConvert.Size = new System.Drawing.Size(120, 28);
            this.buttonConvert.TabIndex = 0;
            this.buttonConvert.Text = "Convert";
            this.buttonConvert.UseVisualStyleBackColor = true;
            this.buttonConvert.Click += new System.EventHandler(this.buttonConvert_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "XML Folder";
            // 
            // textBoxXML
            // 
            this.textBoxXML.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxXML.Location = new System.Drawing.Point(109, 7);
            this.textBoxXML.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxXML.Name = "textBoxXML";
            this.textBoxXML.Size = new System.Drawing.Size(775, 22);
            this.textBoxXML.TabIndex = 2;
            this.textBoxXML.TextChanged += new System.EventHandler(this.textBoxXML_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 112);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Extension";
            // 
            // textBoxHTML
            // 
            this.textBoxHTML.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxHTML.Location = new System.Drawing.Point(109, 39);
            this.textBoxHTML.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxHTML.Name = "textBoxHTML";
            this.textBoxHTML.Size = new System.Drawing.Size(775, 22);
            this.textBoxHTML.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 43);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "HTML Folder";
            // 
            // comboBoxCases
            // 
            this.comboBoxCases.FormattingEnabled = true;
            this.comboBoxCases.Location = new System.Drawing.Point(109, 108);
            this.comboBoxCases.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxCases.Name = "comboBoxCases";
            this.comboBoxCases.Size = new System.Drawing.Size(287, 24);
            this.comboBoxCases.Sorted = true;
            this.comboBoxCases.TabIndex = 8;
            this.comboBoxCases.SelectionChangeCommitted += new System.EventHandler(this.ExtensionChanged);
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(529, 112);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 17);
            this.label4.TabIndex = 9;
            this.label4.Text = "Exclude Objects";
            // 
            // checkedListBoxExclude
            // 
            this.checkedListBoxExclude.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.checkedListBoxExclude.CheckOnClick = true;
            this.checkedListBoxExclude.FormattingEnabled = true;
            this.checkedListBoxExclude.Location = new System.Drawing.Point(649, 112);
            this.checkedListBoxExclude.Margin = new System.Windows.Forms.Padding(4);
            this.checkedListBoxExclude.Name = "checkedListBoxExclude";
            this.checkedListBoxExclude.Size = new System.Drawing.Size(343, 463);
            this.checkedListBoxExclude.Sorted = true;
            this.checkedListBoxExclude.TabIndex = 12;
            // 
            // folderBrowserDialog1
            // 
            this.folderBrowserDialog1.RootFolder = System.Environment.SpecialFolder.MyDocuments;
            // 
            // buttonBrowseXML
            // 
            this.buttonBrowseXML.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonBrowseXML.Location = new System.Drawing.Point(893, 5);
            this.buttonBrowseXML.Margin = new System.Windows.Forms.Padding(4);
            this.buttonBrowseXML.Name = "buttonBrowseXML";
            this.buttonBrowseXML.Size = new System.Drawing.Size(100, 28);
            this.buttonBrowseXML.TabIndex = 13;
            this.buttonBrowseXML.Text = "Browse";
            this.buttonBrowseXML.UseVisualStyleBackColor = true;
            this.buttonBrowseXML.Click += new System.EventHandler(this.buttonBrowseXML_Click);
            // 
            // buttonBrowseHTML
            // 
            this.buttonBrowseHTML.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonBrowseHTML.Location = new System.Drawing.Point(893, 37);
            this.buttonBrowseHTML.Margin = new System.Windows.Forms.Padding(4);
            this.buttonBrowseHTML.Name = "buttonBrowseHTML";
            this.buttonBrowseHTML.Size = new System.Drawing.Size(100, 28);
            this.buttonBrowseHTML.TabIndex = 14;
            this.buttonBrowseHTML.Text = "Browse";
            this.buttonBrowseHTML.UseVisualStyleBackColor = true;
            this.buttonBrowseHTML.Click += new System.EventHandler(this.buttonBrowseHTML_Click);
            // 
            // buttonHelpXML
            // 
            this.buttonHelpXML.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonHelpXML.Location = new System.Drawing.Point(143, 585);
            this.buttonHelpXML.Margin = new System.Windows.Forms.Padding(4);
            this.buttonHelpXML.Name = "buttonHelpXML";
            this.buttonHelpXML.Size = new System.Drawing.Size(120, 28);
            this.buttonHelpXML.TabIndex = 16;
            this.buttonHelpXML.Text = "Help";
            this.buttonHelpXML.UseVisualStyleBackColor = true;
            this.buttonHelpXML.Click += new System.EventHandler(this.buttonHelpXML_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkArea = new System.Windows.Forms.LinkArea(2, 6);
            this.linkLabel1.Location = new System.Drawing.Point(919, 588);
            this.linkLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(70, 24);
            this.linkLabel1.TabIndex = 17;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "© LitDev";
            this.linkLabel1.UseCompatibleTextRendering = true;
            // 
            // checkBoxCSS
            // 
            this.checkBoxCSS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBoxCSS.AutoSize = true;
            this.checkBoxCSS.Location = new System.Drawing.Point(15, 526);
            this.checkBoxCSS.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxCSS.Name = "checkBoxCSS";
            this.checkBoxCSS.Size = new System.Drawing.Size(106, 21);
            this.checkBoxCSS.TabIndex = 18;
            this.checkBoxCSS.Text = "Include CSS";
            this.checkBoxCSS.UseVisualStyleBackColor = true;
            // 
            // checkBoxRTF
            // 
            this.checkBoxRTF.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBoxRTF.AutoSize = true;
            this.checkBoxRTF.Location = new System.Drawing.Point(15, 554);
            this.checkBoxRTF.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxRTF.Name = "checkBoxRTF";
            this.checkBoxRTF.Size = new System.Drawing.Size(106, 21);
            this.checkBoxRTF.TabIndex = 19;
            this.checkBoxRTF.Text = "Include RTF";
            this.checkBoxRTF.UseVisualStyleBackColor = true;
            // 
            // comboBoxRTF
            // 
            this.comboBoxRTF.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.comboBoxRTF.FormattingEnabled = true;
            this.comboBoxRTF.Items.AddRange(new object[] {
            "Large font",
            "Medium font",
            "Small font",
            "Smallest font"});
            this.comboBoxRTF.Location = new System.Drawing.Point(144, 554);
            this.comboBoxRTF.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxRTF.Name = "comboBoxRTF";
            this.comboBoxRTF.Size = new System.Drawing.Size(119, 24);
            this.comboBoxRTF.TabIndex = 20;
            // 
            // checkBoxHTML
            // 
            this.checkBoxHTML.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBoxHTML.AutoSize = true;
            this.checkBoxHTML.Location = new System.Drawing.Point(15, 469);
            this.checkBoxHTML.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxHTML.Name = "checkBoxHTML";
            this.checkBoxHTML.Size = new System.Drawing.Size(117, 21);
            this.checkBoxHTML.TabIndex = 21;
            this.checkBoxHTML.Text = "Include HTML";
            this.checkBoxHTML.UseVisualStyleBackColor = true;
            // 
            // checkBoxImages
            // 
            this.checkBoxImages.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBoxImages.AutoSize = true;
            this.checkBoxImages.Location = new System.Drawing.Point(15, 498);
            this.checkBoxImages.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxImages.Name = "checkBoxImages";
            this.checkBoxImages.Size = new System.Drawing.Size(166, 21);
            this.checkBoxImages.TabIndex = 22;
            this.checkBoxImages.Text = "Include HTML Images";
            this.checkBoxImages.UseVisualStyleBackColor = true;
            // 
            // buttonBrowseRTF
            // 
            this.buttonBrowseRTF.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonBrowseRTF.Location = new System.Drawing.Point(893, 69);
            this.buttonBrowseRTF.Margin = new System.Windows.Forms.Padding(4);
            this.buttonBrowseRTF.Name = "buttonBrowseRTF";
            this.buttonBrowseRTF.Size = new System.Drawing.Size(100, 28);
            this.buttonBrowseRTF.TabIndex = 25;
            this.buttonBrowseRTF.Text = "Browse";
            this.buttonBrowseRTF.UseVisualStyleBackColor = true;
            this.buttonBrowseRTF.Click += new System.EventHandler(this.buttonBrowseRTF_Click);
            // 
            // textBoxRTF
            // 
            this.textBoxRTF.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxRTF.Location = new System.Drawing.Point(109, 71);
            this.textBoxRTF.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxRTF.Name = "textBoxRTF";
            this.textBoxRTF.Size = new System.Drawing.Size(775, 22);
            this.textBoxRTF.TabIndex = 24;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 75);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 17);
            this.label5.TabIndex = 23;
            this.label5.Text = "RTF Folder";
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.HotTrack = true;
            this.tabControl1.Location = new System.Drawing.Point(16, 15);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1017, 656);
            this.tabControl1.TabIndex = 26;
            this.tabControl1.Selected += new System.Windows.Forms.TabControlEventHandler(this.TabSelected);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Controls.Add(this.checkBoxSeparateFiles);
            this.tabPage1.Controls.Add(this.progressBarXML);
            this.tabPage1.Controls.Add(this.linkLabel1);
            this.tabPage1.Controls.Add(this.textBoxXML);
            this.tabPage1.Controls.Add(this.checkBoxImages);
            this.tabPage1.Controls.Add(this.buttonBrowseRTF);
            this.tabPage1.Controls.Add(this.checkBoxHTML);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.comboBoxRTF);
            this.tabPage1.Controls.Add(this.textBoxRTF);
            this.tabPage1.Controls.Add(this.checkBoxRTF);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.checkBoxCSS);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.buttonHelpXML);
            this.tabPage1.Controls.Add(this.textBoxHTML);
            this.tabPage1.Controls.Add(this.buttonConvert);
            this.tabPage1.Controls.Add(this.comboBoxCases);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.checkedListBoxExclude);
            this.tabPage1.Controls.Add(this.buttonBrowseXML);
            this.tabPage1.Controls.Add(this.buttonBrowseHTML);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(1009, 627);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "XML Conversion";
            // 
            // checkBoxSeparateFiles
            // 
            this.checkBoxSeparateFiles.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.checkBoxSeparateFiles.AutoSize = true;
            this.checkBoxSeparateFiles.Location = new System.Drawing.Point(144, 469);
            this.checkBoxSeparateFiles.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxSeparateFiles.Name = "checkBoxSeparateFiles";
            this.checkBoxSeparateFiles.Size = new System.Drawing.Size(121, 21);
            this.checkBoxSeparateFiles.TabIndex = 27;
            this.checkBoxSeparateFiles.Text = "Separate Files";
            this.checkBoxSeparateFiles.UseVisualStyleBackColor = true;
            // 
            // progressBarXML
            // 
            this.progressBarXML.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBarXML.Location = new System.Drawing.Point(271, 585);
            this.progressBarXML.Margin = new System.Windows.Forms.Padding(4);
            this.progressBarXML.Name = "progressBarXML";
            this.progressBarXML.Size = new System.Drawing.Size(640, 28);
            this.progressBarXML.Step = 20;
            this.progressBarXML.TabIndex = 26;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage2.Controls.Add(this.buttonCompile);
            this.tabPage2.Controls.Add(this.richTextBoxPreview);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.textBoxRoot);
            this.tabPage2.Controls.Add(this.buttonOpen);
            this.tabPage2.Controls.Add(this.buttonRoot);
            this.tabPage2.Controls.Add(this.textBoxKeyWordCount);
            this.tabPage2.Controls.Add(this.progressBarSearcher);
            this.tabPage2.Controls.Add(this.checkBoxCase);
            this.tabPage2.Controls.Add(this.hScrollBar1);
            this.tabPage2.Controls.Add(this.buttonCopy);
            this.tabPage2.Controls.Add(this.checkBoxWholeWord);
            this.tabPage2.Controls.Add(this.listViewSearcher);
            this.tabPage2.Controls.Add(this.textBoxFileCount);
            this.tabPage2.Controls.Add(this.textBoxKeyword);
            this.tabPage2.Controls.Add(this.buttonFilter);
            this.tabPage2.Controls.Add(this.buttonRun);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(1009, 627);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "File Searcher";
            // 
            // buttonCompile
            // 
            this.buttonCompile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCompile.Location = new System.Drawing.Point(867, 234);
            this.buttonCompile.Margin = new System.Windows.Forms.Padding(4);
            this.buttonCompile.Name = "buttonCompile";
            this.buttonCompile.Size = new System.Drawing.Size(133, 28);
            this.buttonCompile.TabIndex = 31;
            this.buttonCompile.Text = "Compile";
            this.buttonCompile.UseVisualStyleBackColor = true;
            this.buttonCompile.Click += new System.EventHandler(this.buttonCompile_Click);
            // 
            // richTextBoxPreview
            // 
            this.richTextBoxPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBoxPreview.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBoxPreview.Location = new System.Drawing.Point(8, 358);
            this.richTextBoxPreview.Margin = new System.Windows.Forms.Padding(4);
            this.richTextBoxPreview.Name = "richTextBoxPreview";
            this.richTextBoxPreview.ReadOnly = true;
            this.richTextBoxPreview.ShowSelectionMargin = true;
            this.richTextBoxPreview.Size = new System.Drawing.Size(991, 261);
            this.richTextBoxPreview.TabIndex = 19;
            this.richTextBoxPreview.Text = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(4, 9);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 17);
            this.label6.TabIndex = 14;
            this.label6.Text = "Root Folder";
            // 
            // textBoxRoot
            // 
            this.textBoxRoot.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxRoot.Location = new System.Drawing.Point(95, 7);
            this.textBoxRoot.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxRoot.Name = "textBoxRoot";
            this.textBoxRoot.Size = new System.Drawing.Size(763, 22);
            this.textBoxRoot.TabIndex = 15;
            this.textBoxRoot.TextChanged += new System.EventHandler(this.textBoxRoot_TextChanged);
            // 
            // buttonOpen
            // 
            this.buttonOpen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonOpen.Location = new System.Drawing.Point(867, 198);
            this.buttonOpen.Margin = new System.Windows.Forms.Padding(4);
            this.buttonOpen.Name = "buttonOpen";
            this.buttonOpen.Size = new System.Drawing.Size(133, 28);
            this.buttonOpen.TabIndex = 24;
            this.buttonOpen.Text = "Open in SB";
            this.buttonOpen.UseVisualStyleBackColor = true;
            this.buttonOpen.Click += new System.EventHandler(this.buttonOpen_Click);
            // 
            // buttonRoot
            // 
            this.buttonRoot.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonRoot.Location = new System.Drawing.Point(867, 5);
            this.buttonRoot.Margin = new System.Windows.Forms.Padding(4);
            this.buttonRoot.Name = "buttonRoot";
            this.buttonRoot.Size = new System.Drawing.Size(133, 28);
            this.buttonRoot.TabIndex = 16;
            this.buttonRoot.Text = "Browse";
            this.buttonRoot.UseVisualStyleBackColor = true;
            this.buttonRoot.Click += new System.EventHandler(this.buttonRoot_Click);
            // 
            // textBoxKeyWordCount
            // 
            this.textBoxKeyWordCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxKeyWordCount.Location = new System.Drawing.Point(867, 326);
            this.textBoxKeyWordCount.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxKeyWordCount.Name = "textBoxKeyWordCount";
            this.textBoxKeyWordCount.ReadOnly = true;
            this.textBoxKeyWordCount.Size = new System.Drawing.Size(132, 22);
            this.textBoxKeyWordCount.TabIndex = 27;
            // 
            // progressBarSearcher
            // 
            this.progressBarSearcher.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBarSearcher.Location = new System.Drawing.Point(11, 326);
            this.progressBarSearcher.Margin = new System.Windows.Forms.Padding(4);
            this.progressBarSearcher.Name = "progressBarSearcher";
            this.progressBarSearcher.Size = new System.Drawing.Size(707, 25);
            this.progressBarSearcher.TabIndex = 28;
            // 
            // checkBoxCase
            // 
            this.checkBoxCase.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBoxCase.AutoSize = true;
            this.checkBoxCase.Location = new System.Drawing.Point(872, 38);
            this.checkBoxCase.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxCase.Name = "checkBoxCase";
            this.checkBoxCase.Size = new System.Drawing.Size(123, 21);
            this.checkBoxCase.TabIndex = 23;
            this.checkBoxCase.Text = "Case Sensitive";
            this.checkBoxCase.UseVisualStyleBackColor = true;
            // 
            // hScrollBar1
            // 
            this.hScrollBar1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.hScrollBar1.LargeChange = 1;
            this.hScrollBar1.Location = new System.Drawing.Point(867, 302);
            this.hScrollBar1.Name = "hScrollBar1";
            this.hScrollBar1.Size = new System.Drawing.Size(133, 17);
            this.hScrollBar1.TabIndex = 29;
            this.hScrollBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.SearcherScrollBarChanged);
            // 
            // buttonCopy
            // 
            this.buttonCopy.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonCopy.Location = new System.Drawing.Point(867, 162);
            this.buttonCopy.Margin = new System.Windows.Forms.Padding(4);
            this.buttonCopy.Name = "buttonCopy";
            this.buttonCopy.Size = new System.Drawing.Size(133, 28);
            this.buttonCopy.TabIndex = 25;
            this.buttonCopy.Text = "Copy to Clipboard";
            this.buttonCopy.UseVisualStyleBackColor = true;
            this.buttonCopy.Click += new System.EventHandler(this.buttonCopy_Click);
            // 
            // checkBoxWholeWord
            // 
            this.checkBoxWholeWord.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBoxWholeWord.AutoSize = true;
            this.checkBoxWholeWord.Checked = true;
            this.checkBoxWholeWord.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxWholeWord.Location = new System.Drawing.Point(873, 66);
            this.checkBoxWholeWord.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxWholeWord.Name = "checkBoxWholeWord";
            this.checkBoxWholeWord.Size = new System.Drawing.Size(108, 21);
            this.checkBoxWholeWord.TabIndex = 22;
            this.checkBoxWholeWord.Text = "Whole Word";
            this.checkBoxWholeWord.UseVisualStyleBackColor = true;
            // 
            // listViewSearcher
            // 
            this.listViewSearcher.AllowColumnReorder = true;
            this.listViewSearcher.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listViewSearcher.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.listViewSearcher.FullRowSelect = true;
            this.listViewSearcher.GridLines = true;
            this.listViewSearcher.HideSelection = false;
            this.listViewSearcher.Location = new System.Drawing.Point(8, 38);
            this.listViewSearcher.Margin = new System.Windows.Forms.Padding(4);
            this.listViewSearcher.MultiSelect = false;
            this.listViewSearcher.Name = "listViewSearcher";
            this.listViewSearcher.Size = new System.Drawing.Size(849, 280);
            this.listViewSearcher.TabIndex = 18;
            this.listViewSearcher.UseCompatibleStateImageBehavior = false;
            this.listViewSearcher.View = System.Windows.Forms.View.Details;
            this.listViewSearcher.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.ColumnClick);
            this.listViewSearcher.SelectedIndexChanged += new System.EventHandler(this.SearcherItemChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "File Name";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Line Count";
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Date";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Folder";
            // 
            // textBoxFileCount
            // 
            this.textBoxFileCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxFileCount.Location = new System.Drawing.Point(725, 326);
            this.textBoxFileCount.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxFileCount.Name = "textBoxFileCount";
            this.textBoxFileCount.ReadOnly = true;
            this.textBoxFileCount.Size = new System.Drawing.Size(132, 22);
            this.textBoxFileCount.TabIndex = 30;
            // 
            // textBoxKeyword
            // 
            this.textBoxKeyword.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxKeyword.Location = new System.Drawing.Point(867, 95);
            this.textBoxKeyword.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxKeyword.Name = "textBoxKeyword";
            this.textBoxKeyword.Size = new System.Drawing.Size(132, 22);
            this.textBoxKeyword.TabIndex = 20;
            this.textBoxKeyword.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FilterKeyDown);
            // 
            // buttonFilter
            // 
            this.buttonFilter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonFilter.Location = new System.Drawing.Point(867, 127);
            this.buttonFilter.Margin = new System.Windows.Forms.Padding(4);
            this.buttonFilter.Name = "buttonFilter";
            this.buttonFilter.Size = new System.Drawing.Size(133, 28);
            this.buttonFilter.TabIndex = 21;
            this.buttonFilter.Text = "Apply Filter";
            this.buttonFilter.UseVisualStyleBackColor = true;
            this.buttonFilter.Click += new System.EventHandler(this.buttonFilter_Click);
            // 
            // buttonRun
            // 
            this.buttonRun.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonRun.Location = new System.Drawing.Point(867, 270);
            this.buttonRun.Margin = new System.Windows.Forms.Padding(4);
            this.buttonRun.Name = "buttonRun";
            this.buttonRun.Size = new System.Drawing.Size(133, 28);
            this.buttonRun.TabIndex = 26;
            this.buttonRun.Text = "Run";
            this.buttonRun.UseVisualStyleBackColor = true;
            this.buttonRun.Click += new System.EventHandler(this.buttonRun_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage3.Controls.Add(this.buttonCurriculum);
            this.tabPage3.Controls.Add(this.buttonRefresh);
            this.tabPage3.Controls.Add(this.hScrollBar2);
            this.tabPage3.Controls.Add(this.buttonExtensions);
            this.tabPage3.Controls.Add(this.buttonHome);
            this.tabPage3.Controls.Add(this.buttonBlog);
            this.tabPage3.Controls.Add(this.buttonWiki);
            this.tabPage3.Controls.Add(this.buttonForum);
            this.tabPage3.Controls.Add(this.webBrowser1);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage3.Size = new System.Drawing.Size(1009, 627);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Web Links";
            // 
            // buttonCurriculum
            // 
            this.buttonCurriculum.Location = new System.Drawing.Point(548, 7);
            this.buttonCurriculum.Margin = new System.Windows.Forms.Padding(4);
            this.buttonCurriculum.Name = "buttonCurriculum";
            this.buttonCurriculum.Size = new System.Drawing.Size(100, 28);
            this.buttonCurriculum.TabIndex = 10;
            this.buttonCurriculum.Text = "Curriculum";
            this.buttonCurriculum.UseVisualStyleBackColor = true;
            this.buttonCurriculum.Click += new System.EventHandler(this.buttonCurriculum_Click);
            // 
            // buttonRefresh
            // 
            this.buttonRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonRefresh.Location = new System.Drawing.Point(903, 7);
            this.buttonRefresh.Margin = new System.Windows.Forms.Padding(4);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new System.Drawing.Size(100, 28);
            this.buttonRefresh.TabIndex = 9;
            this.buttonRefresh.Text = "Refresh";
            this.buttonRefresh.UseVisualStyleBackColor = true;
            this.buttonRefresh.Click += new System.EventHandler(this.buttonRefresh_Click);
            // 
            // hScrollBar2
            // 
            this.hScrollBar2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.hScrollBar2.LargeChange = 1;
            this.hScrollBar2.Location = new System.Drawing.Point(853, 7);
            this.hScrollBar2.Maximum = 1000;
            this.hScrollBar2.Name = "hScrollBar2";
            this.hScrollBar2.Size = new System.Drawing.Size(45, 22);
            this.hScrollBar2.TabIndex = 7;
            this.hScrollBar2.Value = 500;
            this.hScrollBar2.ValueChanged += new System.EventHandler(this.ForwardBackward);
            // 
            // buttonExtensions
            // 
            this.buttonExtensions.Location = new System.Drawing.Point(440, 7);
            this.buttonExtensions.Margin = new System.Windows.Forms.Padding(4);
            this.buttonExtensions.Name = "buttonExtensions";
            this.buttonExtensions.Size = new System.Drawing.Size(100, 28);
            this.buttonExtensions.TabIndex = 5;
            this.buttonExtensions.Text = "Extensions";
            this.buttonExtensions.UseVisualStyleBackColor = true;
            this.buttonExtensions.Click += new System.EventHandler(this.buttonExtensions_Click);
            // 
            // buttonHome
            // 
            this.buttonHome.Location = new System.Drawing.Point(8, 7);
            this.buttonHome.Margin = new System.Windows.Forms.Padding(4);
            this.buttonHome.Name = "buttonHome";
            this.buttonHome.Size = new System.Drawing.Size(100, 28);
            this.buttonHome.TabIndex = 4;
            this.buttonHome.Text = "Home";
            this.buttonHome.UseVisualStyleBackColor = true;
            this.buttonHome.Click += new System.EventHandler(this.buttonHome_Click);
            // 
            // buttonBlog
            // 
            this.buttonBlog.Location = new System.Drawing.Point(224, 7);
            this.buttonBlog.Margin = new System.Windows.Forms.Padding(4);
            this.buttonBlog.Name = "buttonBlog";
            this.buttonBlog.Size = new System.Drawing.Size(100, 28);
            this.buttonBlog.TabIndex = 3;
            this.buttonBlog.Text = "Blog";
            this.buttonBlog.UseVisualStyleBackColor = true;
            this.buttonBlog.Click += new System.EventHandler(this.buttonBlog_Click);
            // 
            // buttonWiki
            // 
            this.buttonWiki.Location = new System.Drawing.Point(332, 7);
            this.buttonWiki.Margin = new System.Windows.Forms.Padding(4);
            this.buttonWiki.Name = "buttonWiki";
            this.buttonWiki.Size = new System.Drawing.Size(100, 28);
            this.buttonWiki.TabIndex = 2;
            this.buttonWiki.Text = "Wiki";
            this.buttonWiki.UseVisualStyleBackColor = true;
            this.buttonWiki.Click += new System.EventHandler(this.buttonWiki_Click);
            // 
            // buttonForum
            // 
            this.buttonForum.Location = new System.Drawing.Point(116, 7);
            this.buttonForum.Margin = new System.Windows.Forms.Padding(4);
            this.buttonForum.Name = "buttonForum";
            this.buttonForum.Size = new System.Drawing.Size(100, 28);
            this.buttonForum.TabIndex = 1;
            this.buttonForum.Text = "Forum";
            this.buttonForum.UseVisualStyleBackColor = true;
            this.buttonForum.Click += new System.EventHandler(this.buttonForum_Click);
            // 
            // webBrowser1
            // 
            this.webBrowser1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.webBrowser1.Location = new System.Drawing.Point(8, 43);
            this.webBrowser1.Margin = new System.Windows.Forms.Padding(4);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(27, 25);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.ScriptErrorsSuppressed = true;
            this.webBrowser1.Size = new System.Drawing.Size(991, 574);
            this.webBrowser1.TabIndex = 0;
            this.webBrowser1.Navigated += new System.Windows.Forms.WebBrowserNavigatedEventHandler(this.Navigated);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage4.Controls.Add(this.textBoxAPI);
            this.tabPage4.Controls.Add(this.progressBarAPI);
            this.tabPage4.Controls.Add(this.buttonLoad);
            this.tabPage4.Controls.Add(this.buttonExpand);
            this.tabPage4.Controls.Add(this.buttonCollapseAll);
            this.tabPage4.Controls.Add(this.buttonSearch);
            this.tabPage4.Controls.Add(this.textBoxSearch);
            this.tabPage4.Controls.Add(this.treeView1);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage4.Size = new System.Drawing.Size(1009, 627);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Extension API";
            // 
            // textBoxAPI
            // 
            this.textBoxAPI.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxAPI.Location = new System.Drawing.Point(573, 7);
            this.textBoxAPI.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxAPI.Name = "textBoxAPI";
            this.textBoxAPI.ReadOnly = true;
            this.textBoxAPI.Size = new System.Drawing.Size(283, 22);
            this.textBoxAPI.TabIndex = 7;
            this.textBoxAPI.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // progressBarAPI
            // 
            this.progressBarAPI.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBarAPI.Location = new System.Drawing.Point(8, 588);
            this.progressBarAPI.Margin = new System.Windows.Forms.Padding(4);
            this.progressBarAPI.Name = "progressBarAPI";
            this.progressBarAPI.Size = new System.Drawing.Size(991, 28);
            this.progressBarAPI.TabIndex = 6;
            // 
            // buttonLoad
            // 
            this.buttonLoad.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonLoad.Location = new System.Drawing.Point(865, 7);
            this.buttonLoad.Margin = new System.Windows.Forms.Padding(4);
            this.buttonLoad.Name = "buttonLoad";
            this.buttonLoad.Size = new System.Drawing.Size(133, 28);
            this.buttonLoad.TabIndex = 5;
            this.buttonLoad.Text = "Load";
            this.buttonLoad.UseVisualStyleBackColor = true;
            this.buttonLoad.Click += new System.EventHandler(this.buttonLoad_Click);
            // 
            // buttonExpand
            // 
            this.buttonExpand.Location = new System.Drawing.Point(432, 7);
            this.buttonExpand.Margin = new System.Windows.Forms.Padding(4);
            this.buttonExpand.Name = "buttonExpand";
            this.buttonExpand.Size = new System.Drawing.Size(133, 28);
            this.buttonExpand.TabIndex = 4;
            this.buttonExpand.Text = "Expand Selection";
            this.buttonExpand.UseVisualStyleBackColor = true;
            this.buttonExpand.Click += new System.EventHandler(this.buttonExpand_Click);
            // 
            // buttonCollapseAll
            // 
            this.buttonCollapseAll.Location = new System.Drawing.Point(291, 7);
            this.buttonCollapseAll.Margin = new System.Windows.Forms.Padding(4);
            this.buttonCollapseAll.Name = "buttonCollapseAll";
            this.buttonCollapseAll.Size = new System.Drawing.Size(133, 28);
            this.buttonCollapseAll.TabIndex = 3;
            this.buttonCollapseAll.Text = "Collapse All";
            this.buttonCollapseAll.UseVisualStyleBackColor = true;
            this.buttonCollapseAll.Click += new System.EventHandler(this.buttonCollapseAll_Click);
            // 
            // buttonSearch
            // 
            this.buttonSearch.Location = new System.Drawing.Point(149, 7);
            this.buttonSearch.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(133, 28);
            this.buttonSearch.TabIndex = 2;
            this.buttonSearch.Text = "Search";
            this.buttonSearch.UseVisualStyleBackColor = true;
            this.buttonSearch.Click += new System.EventHandler(this.buttonSearch_Click);
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Location = new System.Drawing.Point(8, 7);
            this.textBoxSearch.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(132, 22);
            this.textBoxSearch.TabIndex = 1;
            this.textBoxSearch.Text = "SearchText";
            // 
            // treeView1
            // 
            this.treeView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.treeView1.BackColor = System.Drawing.SystemColors.Window;
            this.treeView1.Location = new System.Drawing.Point(8, 39);
            this.treeView1.Margin = new System.Windows.Forms.Padding(4);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(989, 541);
            this.treeView1.TabIndex = 0;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1049, 686);
            this.Controls.Add(this.tabControl1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Small Basic Utilities";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.OnClosing);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonConvert;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxXML;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxHTML;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBoxCases;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckedListBox checkedListBoxExclude;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.Button buttonBrowseXML;
        private System.Windows.Forms.Button buttonBrowseHTML;
        private System.Windows.Forms.Button buttonHelpXML;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.CheckBox checkBoxCSS;
        private System.Windows.Forms.CheckBox checkBoxRTF;
        private System.Windows.Forms.ComboBox comboBoxRTF;
        private System.Windows.Forms.CheckBox checkBoxHTML;
        private System.Windows.Forms.CheckBox checkBoxImages;
        private System.Windows.Forms.Button buttonBrowseRTF;
        private System.Windows.Forms.TextBox textBoxRTF;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ProgressBar progressBarXML;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.Button buttonForum;
        private System.Windows.Forms.Button buttonBlog;
        private System.Windows.Forms.Button buttonWiki;
        private System.Windows.Forms.Button buttonHome;
        private System.Windows.Forms.Button buttonExtensions;
        private System.Windows.Forms.HScrollBar hScrollBar2;
        private System.Windows.Forms.TextBox textBoxRoot;
        private System.Windows.Forms.TextBox textBoxKeyWordCount;
        private System.Windows.Forms.HScrollBar hScrollBar1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxFileCount;
        private System.Windows.Forms.Button buttonRun;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.Button buttonCopy;
        private System.Windows.Forms.ProgressBar progressBarSearcher;
        private System.Windows.Forms.Button buttonOpen;
        private System.Windows.Forms.Button buttonRoot;
        private System.Windows.Forms.CheckBox checkBoxCase;
        private System.Windows.Forms.CheckBox checkBoxWholeWord;
        private System.Windows.Forms.TextBox textBoxKeyword;
        private System.Windows.Forms.Button buttonFilter;
        private System.Windows.Forms.RichTextBox richTextBoxPreview;
        private System.Windows.Forms.Timer timer2;
        public System.Windows.Forms.ListView listViewSearcher;
        private System.Windows.Forms.Button buttonCompile;
        private System.Windows.Forms.Button buttonRefresh;
        private System.Windows.Forms.Button buttonCurriculum;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.Button buttonExpand;
        private System.Windows.Forms.Button buttonCollapseAll;
        private System.Windows.Forms.Button buttonSearch;
        private System.Windows.Forms.Button buttonLoad;
        private System.Windows.Forms.ProgressBar progressBarAPI;
        private System.Windows.Forms.TextBox textBoxAPI;
        private System.Windows.Forms.CheckBox checkBoxSeparateFiles;
    }
}

