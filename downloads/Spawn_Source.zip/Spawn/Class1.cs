﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SmallBasic.Library;

namespace Spawn
{
    /// <summary>
    /// Control an external application.
    /// </summary>
    [SmallBasicType]
    public static class Process
    {
        /// <summary>
        /// Start an external application.
        /// </summary>
        /// <param name="application">
        /// The full path of the application to start e.g. C:/Program Files/Microsoft/Small Basic/SB.exe.
        /// </param>
        /// <returns>
        /// Process ID of started application or -1 if failed.
        /// </returns>
        public static Primitive Start(Primitive application)
        {
            try
            {
                return System.Diagnostics.Process.Start(application).Id;
            }
            catch
            {
                return -1;
            }
        }

        /// <summary>
        /// Stop an external process.
        /// </summary>
        /// <param name="ID">
        /// The process ID to stop.
        /// </param>
        /// <returns>
        /// "True" or "False" for success or failure.
        /// </returns>
        public static Primitive Stop(Primitive ID)
        {
            try
            {
                System.Diagnostics.Process.GetProcessById(ID).Kill();
                return "True";
            }
            catch
            {
                return "False";
            }
        }

        /// <summary>
        /// Get a list of system processes.
        /// </summary>
        /// <returns>
        /// An array of all the system process IDs, indexed by the process name.
        /// </returns>
        public static Primitive GetProcesses()
        {
            try
            {
                System.Diagnostics.Process []proc =  System.Diagnostics.Process.GetProcesses();
                int count = proc.GetLength(0);
                int i, j;

                //Get name and ID
                String[] ID = new String[count];
                String[] name = new String[count];
                for (i = 0; i < count; i++)
                {
                    ID[i] = String.Format("{0:D}", proc[i].Id);
                    name[i] = proc[i].ProcessName;
                }

                //Sort alphabetically on name
                String temp;
                for (i = 0; i < count-1; i++)
                {
                    for (j = i+1; j < count; j++)
                    {
                        if (String.Compare(name[j],name[i]) < 0)
                        {
                            temp = ID[i];
                            ID[i] = ID[j];
                            ID[j] = temp;
                            temp = name[i];
                            name[i] = name[j];
                            name[j] = temp;
                        }
                    }
                }

                //Convert to SB array dictionary
                String processes = "";
                for (i = 0; i < count; i++)
                {
                    processes = processes + name[i] + "=" + ID[i] + ";";
                }

                return processes;
            }
            catch
            {
                return "";
            }
        }
    }
}
